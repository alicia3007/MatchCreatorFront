"use client";

import { useState } from "react";
import { useUser, Company, Creator } from "@/app/context/UserContext";
import { Star, MessageSquare, Users, CheckCircle, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";

export default function CompanyReviews() {
  const { currentUser, campaigns, applications, creators, companies, addReview } = useUser();
  const company = currentUser as Company;
  const { t } = useTranslation();

  const [activeTab, setActiveTab] = useState<"received" | "write">("received");
  const [selectedCreatorId, setSelectedCreatorId] = useState<string | null>(null);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const currentCompany = companies.find((c) => c.id === company?.id) || company;
  const averageRating = currentCompany?.rating || 0;
  const reviews = currentCompany?.reviews || [];

  const companyCampaigns = campaigns.filter((c) => c.companyId === company?.id);
  const acceptedApplications = applications.filter(
  (app) => companyCampaigns.some((c) => c.id === app.campaignId) && 
  (app.status === "accepted" || app.status === "confirmed")
);

  const collaboratedCreators = acceptedApplications
    .map((app) => creators.find((c) => c.id === app.creatorId))
    .filter((creator, index, self) => creator && self.findIndex((c) => c?.id === creator.id) === index) as Creator[];

  const hasReviewedCreator = (creatorId: string) => {
    const creator = creators.find((c) => c.id === creatorId);
    return creator?.reviews.some((r) => r.from === company.name) || false;
  };

  const handleSubmitReview = () => {
    if (!selectedCreatorId || rating === 0 || !comment.trim()) return;
    setSubmitting(true);

    addReview(selectedCreatorId, "creator", {
      id: `rev-${Date.now()}`,
      from: company.name,
      rating,
      comment: comment.trim(),
      date: new Date().toISOString().split("T")[0],
    });

    setTimeout(() => {
      setSelectedCreatorId(null);
      setRating(0);
      setComment("");
      setSubmitting(false);
    }, 500);

    toast.success(t("companyReviews.toast.reviewSubmitted"));
  };

  return (
    <div className="flex-1 p-8">
      <div className="max-w-5xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t("companyReviews.title")}</h1>
          <p className="text-gray-600">{t("companyReviews.subtitle")}</p>
        </div>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "received" | "write")} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8 bg-white/60 backdrop-blur-sm p-1 rounded-xl">
            <TabsTrigger value="received" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-cyan-500 data-[state=active]:text-white transition-all duration-300 rounded-lg">
              <MessageSquare className="w-4 h-4 mr-2" />{t("companyReviews.tabs.received")}
            </TabsTrigger>
            <TabsTrigger value="write" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-cyan-500 data-[state=active]:text-white transition-all duration-300 rounded-lg">
              <Sparkles className="w-4 h-4 mr-2" />{t("companyReviews.tabs.write")}
            </TabsTrigger>
          </TabsList>

          {/* Received */}
          <TabsContent value="received" className="space-y-6">
            <Card className="bg-gradient-to-br from-blue-600 to-cyan-500 rounded-2xl shadow-xl p-8 border-0">
              <div className="text-center text-white">
                <div className="flex items-center justify-center gap-3 mb-4">
                  <div className="bg-white/20 backdrop-blur-sm p-3 rounded-full">
                    <Star className="w-10 h-10 text-yellow-300 fill-yellow-300" />
                  </div>
                  <span className="text-7xl font-bold">{averageRating > 0 ? averageRating.toFixed(1) : t("companyReviews.notAvailable")}</span>
                </div>
                <p className="text-xl text-blue-100">{reviews.length} {reviews.length === 1 ? t("companyReviews.reviewSingular") : t("companyReviews.reviewPlural")}</p>
              </div>
            </Card>

            <Card className="bg-white rounded-2xl shadow-lg p-8 border-0">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <MessageSquare className="w-6 h-6 text-blue-600" />{t("companyReviews.comments")}
              </h2>
              {reviews.length === 0 ? (
                <div className="text-center py-16">
                  <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Star className="w-10 h-10 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{t("companyReviews.emptyReceived.title")}</h3>
                  <p className="text-gray-600">{t("companyReviews.emptyReceived.subtitle")}</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {reviews.map((review, index) => (
                    <div key={review.id} className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50/50 rounded-xl border border-blue-200/50 hover:shadow-lg transition-all hover:scale-[1.02]">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{review.from}</h3>
                          <p className="text-sm text-gray-500 mt-1">{review.date}</p>
                        </div>
                        <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-lg shadow-sm">
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star key={star} className={`w-5 h-5 ${star <= review.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`} />
                            ))}
                          </div>
                          <span className="font-bold text-gray-900">{review.rating}</span>
                        </div>
                      </div>
                      <p className="text-gray-700 leading-relaxed">{review.comment}</p>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </TabsContent>

          {/* Write */}
          <TabsContent value="write" className="space-y-6">
            {collaboratedCreators.length === 0 ? (
              <Card className="bg-white rounded-2xl shadow-lg p-12 border-0">
                <div className="text-center">
                  <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="w-10 h-10 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{t("companyReviews.emptyWrite.title")}</h3>
                  <p className="text-gray-600">{t("companyReviews.emptyWrite.subtitle")}</p>
                </div>
              </Card>
            ) : (
              <>
                <Card className="bg-gradient-to-br from-blue-600 to-cyan-500 rounded-2xl shadow-xl p-6 border-0">
                  <div className="flex items-center gap-3 text-white">
                    <div className="bg-white/20 backdrop-blur-sm p-2 rounded-lg"><Sparkles className="w-6 h-6" /></div>
                    <div>
                      <h3 className="font-semibold">{t("companyReviews.shareExperience.title")}</h3>
                      <p className="text-sm text-blue-100">{t("companyReviews.shareExperience.subtitle")}</p>
                    </div>
                  </div>
                </Card>

                <div className="grid gap-6">
                  {collaboratedCreators.map((creator) => (
                    <Card key={creator.id} className={`p-6 border-2 transition-all duration-300 ${selectedCreatorId === creator.id ? "border-blue-500 bg-blue-50 shadow-xl" : "border-transparent bg-white hover:shadow-lg"}`}>
                      <div className="flex items-start gap-4 mb-4">
                        <img src={creator.avatar} alt={creator.name} className="w-16 h-16 rounded-xl object-cover ring-2 ring-blue-200" />
                        <div className="flex-1">
                          <h3 className="text-xl font-bold text-gray-900">{creator.name}</h3>
                          <p className="text-sm text-gray-600 mt-1">{creator.publicName}</p>
                          <div className="flex flex-wrap gap-2 mt-2">
                            {creator.contentType.slice(0, 3).map((type) => (
                              <span key={type} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">{type}</span>
                            ))}
                          </div>
                          <div className="flex items-center gap-2 mt-2">
                            <CheckCircle className="w-4 h-4 text-green-600" />
                            <span className="text-sm text-green-600 font-medium">{t("companyReviews.creatorCard.completedCollaboration")}</span>
                          </div>
                        </div>
                      </div>

                      {selectedCreatorId === creator.id ? (
                        <div className="space-y-4 mt-6 pt-6 border-t border-blue-200">
                          <div>
                            <label className="block text-sm font-semibold text-gray-900 mb-3">{t("companyReviews.form.rating")}</label>
                            <div className="flex gap-2">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <button key={star} type="button" onClick={() => setRating(star)} onMouseEnter={() => setHoverRating(star)} onMouseLeave={() => setHoverRating(0)} className="transition-transform hover:scale-110">
                                  <Star className={`w-10 h-10 transition-colors ${star <= (hoverRating || rating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`} />
                                </button>
                              ))}
                            </div>
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-gray-900 mb-2">{t("companyReviews.form.comment")}</label>
                            <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder={t("companyReviews.form.commentPlaceholder")} className="min-h-[120px] resize-none border-blue-200 focus:border-blue-500" />
                          </div>
                          <div className="flex gap-3">
                            <Button onClick={handleSubmitReview} disabled={rating === 0 || !comment.trim() || submitting} className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white shadow-lg disabled:opacity-50">
                              {submitting ? <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />{t("companyReviews.form.submitting")}</> : <><CheckCircle className="w-4 h-4 mr-2" />{t("companyReviews.form.submit")}</>}
                            </Button>
                            <Button variant="outline" onClick={() => { setSelectedCreatorId(null); setRating(0); setComment(""); }} className="border-blue-300 text-blue-700 hover:bg-blue-50">
                              {t("companyReviews.form.cancel")}
                            </Button>
                          </div>
                        </div>
                      ) : hasReviewedCreator(creator.id) ? (
                        <div className="mt-4 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
                          <div className="flex items-center gap-2 text-green-700">
                            <CheckCircle className="w-5 h-5" />
                            <span className="font-medium">{t("companyReviews.alreadyReviewed")}</span>
                          </div>
                        </div>
                      ) : (
                        <Button onClick={() => setSelectedCreatorId(creator.id)} className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white shadow-md mt-4">
                          <Star className="w-4 h-4 mr-2" />{t("companyReviews.writeReviewButton")}
                        </Button>
                      )}
                    </Card>
                  ))}
                </div>
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}