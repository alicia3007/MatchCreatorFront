"use client";

import { useParams, useRouter } from "next/navigation";
import { useUser } from "@/app/context/UserContext";
import { useTranslation } from "react-i18next";
import { Building2, Calendar, DollarSign, Target, ArrowLeft, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";

export default function ApplicationDetail() {
  const { id } = useParams();
  const router = useRouter();
  const { t } = useTranslation();
  const { applications, campaigns, updateApplication, addMessage, getOrCreateConversation, currentUser, companies } = useUser();

  const application = applications.find((a) => a.id === id);
  const campaign = application ? campaigns.find((c) => c.id === application.campaignId) : null;

  if (!application || !campaign) {
    return (
      <div className="p-6">
        <p className="text-center text-gray-600">{t("applications.notFound")}</p>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "sent": return "bg-blue-100 text-blue-700 border-blue-200";
      case "reviewing": return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "accepted": return "bg-green-100 text-green-700 border-green-200";
      case "confirmed": return "bg-emerald-100 text-emerald-700 border-emerald-200";
      case "rejected": return "bg-red-100 text-red-700 border-red-200";
      default: return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const getStatusText = (status: string) => t(`applications.status.${status}`, { defaultValue: status });

  const handleAcceptCollaboration = () => {
    if (!currentUser || !campaign) return;
    updateApplication(application.id, { status: "confirmed" });

    const companyData = companies.find((c) => c.id === campaign.companyId);
    if (!companyData) return;

    const conversation = getOrCreateConversation(currentUser.id, "creator", companyData.id, "company");
    addMessage({
      id: `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      conversationId: conversation.id,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: (currentUser as any).avatar || "",
      text: t("applications.acceptMessage", { campaignName: campaign.name }),
      timestamp: new Date().toISOString(),
      read: false,
    });
    toast.success(t("applications.acceptToast"));
    setTimeout(() => router.push("/creator/messages"), 1500);
  };

  const handleRejectCollaboration = () => {
    if (!confirm(t("applications.rejectConfirm"))) return;
    updateApplication(application.id, { status: "rejected" });
    toast.success(t("applications.rejectToast"));
    setTimeout(() => router.push("/creator/applications"), 1500);
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <button onClick={() => router.push("/creator/applications")} className="mb-6 flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-5 h-5" />
        {t("applications.backToApplications")}
      </button>

      {/* Status Banner */}
      <div className={`border-2 rounded-2xl p-6 mb-6 ${getStatusColor(application.status)}`}>
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold mb-1">{t("applications.statusLabel")}: {getStatusText(application.status)}</h2>
            <p className="text-sm">{t("applications.appliedOn")} {application.appliedDate}</p>
          </div>
          {application.status === "accepted" && <CheckCircle className="w-12 h-12" />}
          {application.status === "rejected" && <XCircle className="w-12 h-12" />}
        </div>
      </div>

      {/* Campaign Details */}
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{campaign.name}</h1>
          <div className="flex items-center gap-2 text-gray-600">
            <Building2 className="w-5 h-5" />
            <span className="text-lg">{campaign.companyName}</span>
          </div>
        </div>

        <div className="mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-3">{t("applications.campaignDescription")}</h2>
          <p className="text-gray-700 leading-relaxed">{campaign.description}</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <div className="p-4 bg-purple-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-5 h-5 text-purple-600" />
              <h3 className="font-semibold text-gray-900">{t("applications.budget")}</h3>
            </div>
            <p className="text-lg font-bold text-purple-600">{campaign.budget}</p>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-5 h-5 text-purple-600" />
              <h3 className="font-semibold text-gray-900">{t("applications.dates")}</h3>
            </div>
            <p className="text-gray-700">
              {new Date(campaign.startDate).toLocaleDateString()} - {new Date(campaign.endDate).toLocaleDateString()}
            </p>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-5 h-5 text-purple-600" />
              <h3 className="font-semibold text-gray-900">{t("applications.objective")}</h3>
            </div>
            <p className="text-gray-700">{campaign.objective}</p>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-purple-600" />
              <h3 className="font-semibold text-gray-900">{t("applications.totalApplicants")}</h3>
            </div>
            <p className="text-lg font-bold text-purple-600">{campaign.applicants.length}</p>
          </div>
        </div>

        {/* Status-specific actions */}
        {application.status === "accepted" && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-gray-900">{t("applications.nextStep")}</h2>
            <div className="flex gap-4">
              <button onClick={handleAcceptCollaboration} className="flex-1 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-semibold">
                {t("applications.acceptCollaboration")}
              </button>
              <button onClick={handleRejectCollaboration} className="flex-1 px-6 py-3 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors font-semibold">
                {t("applications.rejectCollaboration")}
              </button>
            </div>
          </div>
        )}

        {application.status === "sent" && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-blue-900 font-semibold">{t("applications.sentTitle")}</p>
            <p className="text-blue-700 text-sm mt-1">{t("applications.sentDesc")}</p>
          </div>
        )}
        {application.status === "reviewing" && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p className="text-yellow-900 font-semibold">{t("applications.reviewingTitle")}</p>
            <p className="text-yellow-700 text-sm mt-1">{t("applications.reviewingDesc")}</p>
          </div>
        )}
        {application.status === "rejected" && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-900 font-semibold">{t("applications.rejectedTitle")}</p>
            <p className="text-red-700 text-sm mt-1">{t("applications.rejectedDesc")}</p>
          </div>
        )}
        {application.status === "confirmed" && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
            <p className="text-emerald-900 font-semibold">{t("applications.confirmedTitle")}</p>
            <p className="text-emerald-700 text-sm mt-1">{t("applications.confirmedDesc")}</p>
            <button onClick={() => router.push("/creator/messages")} className="mt-3 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors font-semibold text-sm">
              {t("applications.goToMessages")}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}