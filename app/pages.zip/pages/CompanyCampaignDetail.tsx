"use client";

import { useParams, useRouter } from "next/navigation";
import { useUser, Creator, MATCH_CREATOR_SYSTEM } from "@/app/context/UserContext";
import { useTranslation } from "react-i18next";
import {
  Building2, DollarSign, Calendar, ArrowLeft, Users, Edit,
  CheckCircle, XCircle, TrendingUp, Star, Eye, ListChecks,
  Package, ImageIcon, Instagram, Youtube, Twitter, Facebook,
} from "lucide-react";
import { useState } from "react";

const getPlatformColors = (platform: string) => {
  const p = platform.toLowerCase();
  if (p.includes("instagram")) return "bg-gradient-to-tr from-[#f9ce34] via-[#ee2a7b] to-[#6228d7] text-white";
  if (p.includes("youtube")) return "bg-[#FF0000] text-white";
  if (p.includes("tiktok")) return "bg-black text-white";
  if (p.includes("twitter") || p.includes("x")) return "bg-black text-white";
  if (p.includes("facebook")) return "bg-[#1877F2] text-white";
  if (p.includes("twitch")) return "bg-[#9146FF] text-white";
  return "bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8] text-white";
};

const getPlatformIcon = (platform: string) => {
  const p = platform.toLowerCase();
  if (p.includes("instagram")) return <Instagram className="w-4 h-4" />;
  if (p.includes("youtube")) return <Youtube className="w-4 h-4" />;
  if (p.includes("tiktok")) return (
    <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current">
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.69a8.18 8.18 0 0 0 4.78 1.52V6.75a4.85 4.85 0 0 1-1.01-.06z"/>
    </svg>
  );
  if (p.includes("twitter") || p.includes("x")) return <Twitter className="w-4 h-4" />;
  if (p.includes("facebook")) return <Facebook className="w-4 h-4" />;
  if (p.includes("twitch")) return (
    <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current">
      <path d="M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L22.286 12V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714z"/>
    </svg>
  );
  return <TrendingUp className="w-4 h-4" />;
};

export default function CompanyCampaignDetail() {
  const { t } = useTranslation();
  const { id } = useParams();
  const router = useRouter();
  const {
    campaigns, updateCampaign, applications, updateApplication,
    creators, addMessage, addNotification, getOrCreateConversation,
    companies, currentUser, addConversation, conversations, userType,
  } = useUser();
  const [selectedTab, setSelectedTab] = useState<"overview" | "applicants">("overview");

  const campaign = campaigns.find((c) => c.id === id);
  const campaignApplications = applications.filter((app) => app.campaignId === id);

  if (!campaign) {
    return (
      <main className="flex-1 overflow-y-auto p-8">
        <p className="text-center text-gray-600">{t("companyCampaignDetail.notFound")}</p>
      </main>
    );
  }

  const handleCloseCampaign = () => {
    if (confirm(t("companyCampaignDetail.confirmClose"))) {
      updateCampaign(campaign.id, { status: "closed" });
    }
  };

  const handleEditCampaign = () => {
    router.push(`/company/campaigns/new?campaignId=${campaign.id}`);
  };

  const getOrCreateSystemConversation = (creatorId: string, creatorName: string, creatorAvatar: string) => {
    const existing = conversations.find(
      (conv) => conv.participants.some((p) => p.id === creatorId) && conv.participants.some((p) => p.id === MATCH_CREATOR_SYSTEM.id)
    );
    if (existing) return existing;
    const newConv = {
      id: `conv-system-creator-${creatorId}-${Date.now()}`,
      participants: [
        { id: creatorId, name: creatorName, avatar: creatorAvatar, type: "creator" as const },
        { ...MATCH_CREATOR_SYSTEM },
      ],
      lastMessage: undefined,
      unreadCount: 0,
      unreadByUser: { [creatorId]: 1 },
    };
    addConversation(newConv);
    return newConv;
  };

  const handleAcceptApplication = (appId: string) => {
    const application = applications.find((a) => a.id === appId);
    if (!application || !currentUser) return;
    const creator = creators.find((c) => c.id === application.creatorId);
    if (!creator) return;
    const companyData = companies.find((c) => c.id === campaign.companyId);
    updateApplication(appId, { status: "accepted" });
    const conversation = getOrCreateConversation(currentUser.id, userType as "creator" | "company", creator.id, "creator");
    addConversation({
      ...conversation,
      participants: [
        { id: currentUser.id, name: currentUser.name, avatar: (currentUser as any).logo || (currentUser as any).avatar || "", type: userType as "creator" | "company" },
        { id: creator.id, name: creator.name, avatar: creator.avatar, type: "creator" as const },
      ],
      unreadByUser: { [creator.id]: 1, [currentUser.id]: 0 },
    });
    addMessage({
      id: `msg-company-${Date.now()}`,
      conversationId: conversation.id,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: companyData?.logo || (currentUser as any).logo || "",
      text: t("companyCampaignDetail.messages.acceptedCompany", { creatorName: creator.name, campaignName: campaign.name }),
      timestamp: new Date().toISOString(),
      read: false,
    });
    const systemConv = getOrCreateSystemConversation(creator.id, creator.name, creator.avatar);
    addMessage({
      id: `msg-system-${Date.now()}`,
      conversationId: systemConv.id,
      senderId: MATCH_CREATOR_SYSTEM.id,
      senderName: MATCH_CREATOR_SYSTEM.name,
      senderAvatar: MATCH_CREATOR_SYSTEM.avatar,
      text: t("companyCampaignDetail.messages.acceptedSystem", { campaignName: campaign.name, companyName: campaign.companyName }),
      timestamp: new Date().toISOString(),
      read: false,
    });
    addNotification({
      id: `notif-${Date.now()}`,
      userId: creator.id,
      type: "accepted",
      title: t("companyCampaignDetail.notifications.acceptedTitle"),
      message: t("companyCampaignDetail.notifications.acceptedMessage", { campaignName: campaign.name }),
      campaignId: campaign.id,
      campaignName: campaign.name,
      read: false,
      timestamp: new Date().toISOString(),
    });
    router.push("/company/messages");
  };

  const handleRejectApplication = (appId: string) => {
    if (!confirm(t("companyCampaignDetail.confirmReject"))) return;
    const application = applications.find((a) => a.id === appId);
    if (!application) return;
    const creator = creators.find((c) => c.id === application.creatorId);
    if (!creator) return;
    updateApplication(appId, { status: "rejected" });
    const systemConv = getOrCreateSystemConversation(creator.id, creator.name, creator.avatar);
    addMessage({
      id: `msg-system-${Date.now()}`,
      conversationId: systemConv.id,
      senderId: MATCH_CREATOR_SYSTEM.id,
      senderName: MATCH_CREATOR_SYSTEM.name,
      senderAvatar: MATCH_CREATOR_SYSTEM.avatar,
      text: t("companyCampaignDetail.messages.rejectedSystem", { campaignName: campaign.name, companyName: campaign.companyName }),
      timestamp: new Date().toISOString(),
      read: false,
    });
    addNotification({
      id: `notif-${Date.now()}`,
      userId: creator.id,
      type: "rejected",
      title: t("companyCampaignDetail.notifications.rejectedTitle"),
      message: t("companyCampaignDetail.notifications.rejectedMessage", { campaignName: campaign.name }),
      campaignId: campaign.id,
      campaignName: campaign.name,
      read: false,
      timestamp: new Date().toISOString(),
    });
  };

  const getStatusStyle = (status: string) => {
    switch (status) {
      case "sent": return "bg-blue-100 text-blue-700";
      case "reviewing": return "bg-yellow-100 text-yellow-700";
      case "accepted": return "bg-green-100 text-green-700";
      case "rejected": return "bg-red-100 text-red-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const c = campaign as any;
  const categories: string[] = c.categories || c.creatorType || [];
  const platforms: string[] = c.socialPlatform || [];
  const requirements: any[] = c.requirements_list || (Array.isArray(c.requirements) ? c.requirements.map((r: string, i: number) => ({ id: `r${i}`, text: r })) : []);
  const deliverables: any[] = c.deliverables || [];
  const bannerImage: string | null = c.bannerImage || null;
  const mainImage: string | null = c.mainImage || null;
  const acceptedCount = campaignApplications.filter((a) => a.status === "accepted").length;

  return (
    <main className="flex-1 overflow-y-auto">
      {/* Header — igual pero un poco más compacto */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="px-6 py-3 flex items-center justify-between">
          <button onClick={() => router.push("/company/campaigns")} className="flex items-center gap-2 text-gray-500 hover:text-[#0EA5E9] transition-colors font-medium text-sm">
            <ArrowLeft className="w-4 h-4" />{t("companyCampaignDetail.backToCampaigns")}
          </button>
          <div className="flex gap-2">
            <button onClick={handleEditCampaign} className="px-3 py-1.5 rounded-xl bg-sky-50 text-[#0EA5E9] hover:bg-sky-100 transition-colors flex items-center gap-1.5 text-xs font-semibold">
              <Edit className="w-3.5 h-3.5" />{t("common.edit")}
            </button>
            {campaign.status === "active" && (
              <button onClick={handleCloseCampaign} className="px-3 py-1.5 rounded-xl bg-red-50 text-red-600 hover:bg-red-100 transition-colors text-xs font-semibold">
                {t("companyCampaignDetail.closeCampaign")}
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="p-6 max-w-6xl mx-auto">
        {/* Header card */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-5">
          <div className="h-44 relative overflow-hidden bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8]">
            {bannerImage ? (
              <img src={bannerImage} alt="Banner" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center opacity-20">
                <ImageIcon className="w-24 h-24 text-white" />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/60" />
            <div className={`absolute top-3 right-3 px-4 py-2 rounded-xl font-bold text-xs shadow-2xl flex items-center gap-1.5 ${campaign.status === "active" ? "bg-green-500 text-white" : "bg-gray-500 text-white"}`}>
              <div className={`w-1.5 h-1.5 rounded-full ${campaign.status === "active" ? "bg-white animate-pulse" : "bg-gray-300"}`} />
              {campaign.status === "active" ? t("companyCampaignDetail.statusActive") : t("companyCampaignDetail.statusClosed")}
            </div>
          </div>

          <div className="p-6">
            <div className="flex items-start gap-5 mb-5">
              {mainImage && (
                <div className="w-24 h-24 rounded-2xl overflow-hidden border-4 border-white shadow-xl flex-shrink-0 -mt-16 relative z-10 bg-white">
                  <img src={mainImage} alt="Campaign" className="w-full h-full object-cover" />
                </div>
              )}
              <div>
                <h1 className="text-3xl font-black text-[#1F2937] mb-1.5">{campaign.name}</h1>
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8] rounded-xl flex items-center justify-center">
                    <Building2 className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium">{t("companyCampaignDetail.yourCompany")}</p>
                    <p className="text-base font-bold text-[#0EA5E9]">{campaign.companyName}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Stats — un poco más pequeñas */}
            <div className="grid grid-cols-3 gap-3 mb-5">
              <div className="bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8] text-white rounded-2xl p-4 shadow-lg hover:scale-105 transition-transform">
                <div className="flex items-center gap-2.5 mb-1">
                  <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center"><DollarSign className="w-4 h-4" /></div>
                  <p className="text-xl font-black">{campaign.budget}</p>
                </div>
                <p className="text-xs font-semibold text-white/90">{t("companyCampaignDetail.stats.budget")}</p>
              </div>
              <div className="bg-gradient-to-br from-violet-500 to-purple-600 text-white rounded-2xl p-4 shadow-lg hover:scale-105 transition-transform">
                <div className="flex items-center gap-2.5 mb-1">
                  <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center"><Users className="w-4 h-4" /></div>
                  <p className="text-xl font-black">{campaignApplications.length}</p>
                </div>
                <p className="text-xs font-semibold text-white/90">{t("companyCampaignDetail.stats.applications")}</p>
              </div>
              <div className="bg-gradient-to-br from-emerald-500 to-teal-500 text-white rounded-2xl p-4 shadow-lg hover:scale-105 transition-transform">
                <div className="flex items-center gap-2.5 mb-1">
                  <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center"><Calendar className="w-4 h-4" /></div>
                  <p className="text-xs font-black leading-tight">
                    {new Date(campaign.startDate).toLocaleDateString("es-ES", { day: "2-digit", month: "short" })}
                    {" – "}
                    {new Date(campaign.endDate).toLocaleDateString("es-ES", { day: "2-digit", month: "short" })}
                  </p>
                </div>
                <p className="text-xs font-semibold text-white/90">{t("companyCampaignDetail.stats.duration")}</p>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {categories.map((cat, i) => (
                <span key={i} className="px-3 py-1.5 bg-gradient-to-r from-[#0EA5E9] to-[#38BDF8] text-white rounded-full text-xs font-bold shadow hover:scale-105 transition-transform">{cat}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-5 border-b border-gray-200">
          <div className="flex gap-2">
            {(["overview", "applicants"] as const).map((tab) => (
              <button key={tab} onClick={() => setSelectedTab(tab)} className={`px-5 py-2.5 font-semibold text-sm transition-all flex items-center gap-2 ${selectedTab === tab ? "text-[#0EA5E9] border-b-2 border-[#0EA5E9]" : "text-gray-500 hover:text-gray-800"}`}>
                {tab === "overview" ? t("companyCampaignDetail.tabs.overview") : t("companyCampaignDetail.tabs.applicants")}
                {tab === "applicants" && campaignApplications.length > 0 && (
                  <span className="px-2 py-0.5 bg-[#0EA5E9] text-white text-xs font-bold rounded-full">{campaignApplications.length}</span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Overview tab */}
        {selectedTab === "overview" && (
          <div className="grid md:grid-cols-3 gap-5">
            <div className="md:col-span-2 space-y-5">
              <div className="bg-white rounded-2xl shadow-lg p-5">
                <h2 className="text-lg font-semibold mb-3 flex items-center gap-2 text-[#1F2937]">
                  <div className="w-8 h-8 bg-sky-50 rounded-xl flex items-center justify-center"><Package className="w-4 h-4 text-[#0EA5E9]" /></div>
                  {t("companyCampaignDetail.overview.description")}
                </h2>
                <p className="text-gray-700 text-sm leading-relaxed">{campaign.description}</p>
              </div>

              {/* Plataformas — iconos reales en vez de letras */}
              <div className="bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8] rounded-2xl shadow-xl p-6">
                <h2 className="text-lg font-bold mb-4 flex items-center gap-2.5 text-white">
                  <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center"><TrendingUp className="w-4 h-4 text-white" /></div>
                  {t("companyCampaignDetail.overview.platforms")}
                </h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  {platforms.map((platform, i) => (
                    <div key={i} className="p-3 bg-white rounded-xl border-2 border-white/40 hover:border-white transition-all hover:shadow-xl hover:scale-105">
                      <div className="flex items-center gap-3">
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shadow ${getPlatformColors(platform)}`}>
                          {getPlatformIcon(platform)}
                        </div>
                        <div>
                          <p className="font-bold text-[#1F2937] text-sm">{platform}</p>
                          <p className="text-xs text-gray-500">{t("companyCampaignDetail.overview.publishChannel")}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {deliverables.length > 0 && (
                <div className="bg-white rounded-2xl shadow-lg p-5">
                  <h2 className="text-lg font-semibold mb-3 flex items-center gap-2 text-[#1F2937]">
                    <div className="w-8 h-8 bg-sky-50 rounded-xl flex items-center justify-center"><ListChecks className="w-4 h-4 text-[#0EA5E9]" /></div>
                    {t("companyCampaignDetail.overview.deliverables")}
                  </h2>
                  <div className="space-y-2.5">
                    {deliverables.map((d: any, i: number) => (
                      <div key={d.id || i} className="p-3 bg-sky-50 rounded-xl border-l-4 border-[#0EA5E9] flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-[#0EA5E9] text-white text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">{i + 1}</span>
                        <p className="text-gray-700 text-sm leading-relaxed">{d.text || d}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="bg-gradient-to-br from-emerald-500 to-teal-500 rounded-2xl shadow-xl p-5 text-white">
                <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
                  <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center"><CheckCircle className="w-4 h-4" /></div>
                  {t("companyCampaignDetail.overview.selectionSummary")}
                </h2>
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-white/20 rounded-xl p-3 text-center">
                    <p className="text-2xl font-black">{campaignApplications.length}</p>
                    <p className="text-xs text-white/80 mt-1">{t("companyCampaignDetail.overview.totalApplications")}</p>
                  </div>
                  <div className="bg-white/20 rounded-xl p-3 text-center">
                    <p className="text-2xl font-black">{acceptedCount}</p>
                    <p className="text-xs text-white/80 mt-1">{t("companyCampaignDetail.overview.accepted")}</p>
                  </div>
                  <div className="bg-white/20 rounded-xl p-3 text-center">
                    <p className="text-2xl font-black">{campaignApplications.filter((a) => a.status === "sent").length}</p>
                    <p className="text-xs text-white/80 mt-1">{t("companyCampaignDetail.overview.pending")}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-5">
              {requirements.length > 0 && (
                <div className="bg-white rounded-2xl shadow-lg p-5">
                  <h3 className="text-base font-semibold mb-3 flex items-center gap-2 text-[#1F2937]">
                    <CheckCircle className="w-4 h-4 text-[#0EA5E9]" />{t("companyCampaignDetail.overview.requirements")}
                  </h3>
                  <ul className="space-y-2.5">
                    {requirements.map((req: any, i: number) => (
                      <li key={req.id || i} className="flex items-start gap-2.5 group">
                        <div className="w-5 h-5 bg-sky-50 rounded-lg flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                          <CheckCircle className="w-3.5 h-3.5 text-[#0EA5E9]" />
                        </div>
                        <span className="text-gray-700 text-sm leading-relaxed">{req.text || req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="bg-white rounded-2xl shadow-lg p-5">
                <h3 className="text-base font-semibold mb-3 flex items-center gap-2 text-[#1F2937]">
                  <Calendar className="w-4 h-4 text-[#0EA5E9]" />{t("companyCampaignDetail.overview.timeline")}
                </h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded-xl">
                    <span className="text-xs text-gray-600">{t("companyCampaignDetail.overview.startDate")}</span>
                    <span className="text-xs font-semibold text-gray-900">{new Date(campaign.startDate).toLocaleDateString("es-ES")}</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-sky-50 rounded-xl border border-sky-100">
                    <span className="text-xs text-sky-700">{t("companyCampaignDetail.overview.endDate")}</span>
                    <span className="text-xs font-semibold text-sky-900">{new Date(campaign.endDate).toLocaleDateString("es-ES")}</span>
                  </div>
                </div>
              </div>

              <div className="bg-sky-50 border-2 border-sky-200 rounded-2xl p-5">
                <h3 className="font-semibold text-sky-900 mb-1.5 text-sm">{t("companyCampaignDetail.editHint.title")}</h3>
                <p className="text-xs text-sky-700 mb-3">{t("companyCampaignDetail.editHint.subtitle")}</p>
                <button onClick={handleEditCampaign} className="w-full py-2.5 rounded-xl bg-[#0EA5E9] text-white font-semibold text-xs hover:bg-[#0EA5E9]/90 transition-all shadow flex items-center justify-center gap-2">
                  <Edit className="w-3.5 h-3.5" />{t("companyCampaignDetail.editHint.button")}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Applicants tab */}
        {selectedTab === "applicants" && (
          <div className="space-y-3">
            {campaignApplications.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-lg p-14 text-center">
                <Users className="w-12 h-12 text-gray-200 mx-auto mb-3" />
                <h3 className="text-lg font-semibold text-gray-900 mb-1">{t("companyCampaignDetail.applicants.empty.title")}</h3>
                <p className="text-gray-500 text-sm">{t("companyCampaignDetail.applicants.empty.subtitle")}</p>
              </div>
            ) : (
              campaignApplications.map((application) => {
                const creator = creators.find((c) => c.id === application.creatorId);
                if (!creator) return null;
                return (
                  <div key={application.id} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow border border-gray-100">
                    <div className="p-5 flex items-start gap-4">
                      <img src={creator.avatar} alt={creator.name} className="w-16 h-16 rounded-2xl object-cover border-2 border-sky-100 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-3 mb-1">
                          <div>
                            <h3 className="text-base font-bold text-gray-900">{creator.name}</h3>
                            <p className="text-xs text-[#0EA5E9] font-medium">{creator.publicName}</p>
                          </div>
                          <span className={`px-2.5 py-1 rounded-full text-xs font-bold flex-shrink-0 ${getStatusStyle(application.status)}`}>
                            {t(`applications.status.${application.status}`, { defaultValue: application.status })}
                          </span>
                        </div>
                        <p className="text-gray-600 text-xs mb-3 line-clamp-2">{creator.bio}</p>
                        <div className="grid grid-cols-3 gap-2 mb-3">
                          <div className="p-2.5 bg-sky-50 rounded-xl">
                            <div className="flex items-center gap-1 mb-0.5">
                              <Users className="w-3.5 h-3.5 text-[#0EA5E9]" />
                              <span className="text-[10px] font-medium text-gray-500">{t("companyCampaignDetail.applicants.card.followers")}</span>
                            </div>
                            <p className="text-base font-black text-[#0EA5E9]">{creator.socialMedia.reduce((acc, sm) => acc + sm.followers, 0).toLocaleString()}</p>
                          </div>
                          <div className="p-2.5 bg-violet-50 rounded-xl">
                            <div className="flex items-center gap-1 mb-0.5">
                              <TrendingUp className="w-3.5 h-3.5 text-violet-500" />
                              <span className="text-[10px] font-medium text-gray-500">{t("companyCampaignDetail.applicants.card.networks")}</span>
                            </div>
                            <p className="text-base font-black text-violet-600">{creator.socialMedia?.length || 0}</p>
                          </div>
                          <div className="p-2.5 bg-amber-50 rounded-xl">
                            <div className="flex items-center gap-1 mb-0.5">
                              <Star className="w-3.5 h-3.5 text-amber-500" />
                              <span className="text-[10px] font-medium text-gray-500">{t("companyCampaignDetail.applicants.card.rating")}</span>
                            </div>
                            <p className="text-base font-black text-amber-600">{creator.rating > 0 ? creator.rating.toFixed(1) : t("companyCampaignDetail.applicants.card.newCreator")}</p>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-1.5 mb-2">
                          {creator.contentType?.map((type, i) => (
                            <span key={i} className="px-2.5 py-0.5 bg-sky-100 text-[#0EA5E9] rounded-full text-xs font-semibold">{type}</span>
                          ))}
                        </div>
                        <p className="text-xs text-gray-400">{t("companyCampaignDetail.applicants.card.appliedOn")} {new Date(application.appliedDate).toLocaleDateString("es-ES")}</p>
                      </div>

                      <div className="flex flex-col gap-2 flex-shrink-0">
                        <button onClick={() => router.push(`/company/creators/${creator.id}`)} className="px-3.5 py-2 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap">
                          <Eye className="w-3.5 h-3.5" />{t("companyCampaignDetail.applicants.card.viewProfile")}
                        </button>
                        {application.status === "sent" && (
                          <>
                            <button onClick={() => handleAcceptApplication(application.id)} className="px-3.5 py-2 bg-emerald-500 text-white rounded-xl hover:bg-emerald-600 transition-colors flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap">
                              <CheckCircle className="w-3.5 h-3.5" />{t("campaigns.accept")}
                            </button>
                            <button onClick={() => handleRejectApplication(application.id)} className="px-3.5 py-2 bg-red-100 text-red-600 rounded-xl hover:bg-red-200 transition-colors flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap">
                              <XCircle className="w-3.5 h-3.5" />{t("campaigns.reject")}
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>
    </main>
  );
}