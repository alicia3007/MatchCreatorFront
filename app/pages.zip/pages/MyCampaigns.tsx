"use client";

import { useUser, Company } from "@/app/context/UserContext";
import { useRouter } from "next/navigation";
import { Briefcase, Users, ArrowRight, Edit, Power, PowerOff } from "lucide-react";
import { useTranslation } from "react-i18next";

export default function MyCampaigns() {
  const { t } = useTranslation();
  const { campaigns, currentUser, updateCampaign } = useUser();
  const router = useRouter();
  const company = currentUser as Company;

  const myCampaigns = campaigns.filter((c) => c.companyId === company?.id);

  const getStatusColor = (status: string) =>
    status === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700";

  const getStatusText = (status: string) =>
    status === "active" ? t("myCampaigns.status.active") : t("myCampaigns.status.closed");

  const toggleCampaignStatus = (camp: { id: string; status: string }) => {
    updateCampaign(camp.id, { status: camp.status === "active" ? "closed" : "active" });
  };

  return (
    <main className="flex-1 overflow-y-auto p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t("myCampaigns.title")}</h1>
          <p className="text-gray-600">{t("myCampaigns.subtitle")}</p>
        </div>
        <button
          onClick={() => router.push("/company/campaigns/new")}
          className="px-6 py-3 bg-gradient-to-r from-[#0EA5E9] to-[#38BDF8] text-white rounded-lg hover:shadow-lg transition-all font-semibold"
        >
          {t("myCampaigns.newCampaign")}
        </button>
      </div>

      {myCampaigns.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
          <Briefcase className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">{t("myCampaigns.empty.title")}</h2>
          <p className="text-gray-600 mb-6">{t("myCampaigns.empty.subtitle")}</p>
          <button
            onClick={() => router.push("/company/campaigns/new")}
            className="px-6 py-3 bg-gradient-to-r from-[#0EA5E9] to-[#38BDF8] text-white rounded-lg hover:shadow-lg transition-all font-semibold"
          >
            {t("myCampaigns.empty.createBtn")}
          </button>
        </div>
      ) : (
        <div className="grid gap-6">
          {myCampaigns.map((camp) => (
            <div key={camp.id} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow border border-gray-200">
              <div className="flex flex-col md:flex-row justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 mb-2">{camp.name}</h2>
                      <div className="flex items-center gap-2">
                        <span className={`inline-block px-4 py-1 rounded-full text-sm font-semibold ${getStatusColor(camp.status)}`}>
                          {getStatusText(camp.status)}
                        </span>
                        <button
                          onClick={() => toggleCampaignStatus(camp)}
                          className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium transition-colors ${camp.status === "active" ? "bg-red-100 text-red-700 hover:bg-red-200" : "bg-green-100 text-green-700 hover:bg-green-200"}`}
                        >
                          {camp.status === "active"
                            ? <><PowerOff className="w-3 h-3" />{t("myCampaigns.actions.close")}</>
                            : <><Power className="w-3 h-3" />{t("myCampaigns.actions.activate")}</>}
                        </button>
                      </div>
                    </div>
                  </div>

                  <p className="text-gray-700 mb-4 line-clamp-2">{camp.description}</p>

                  <div className="flex flex-wrap items-center gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-[#0EA5E9]" />
                      <span className="font-semibold text-gray-900">
                        {t("myCampaigns.applicantsCount", { count: camp.applicants.length })}
                      </span>
                    </div>
                    <div className="text-gray-600">
                      📅 {new Date(camp.startDate).toLocaleDateString()} - {new Date(camp.endDate).toLocaleDateString()}
                    </div>
                    {(camp as any).budget && (
                      <div className="text-gray-600">💰 {(camp as any).budget}</div>
                    )}
                  </div>

                  {camp.creatorType && camp.creatorType.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-3">
                      {camp.creatorType.slice(0, 3).map((type, i) => (
                        <span key={i} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                          {type}
                        </span>
                      ))}
                      {camp.creatorType.length > 3 && (
                        <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-medium">
                          {t("myCampaigns.moreTypes", { count: camp.creatorType.length - 3 })}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex md:flex-col justify-end items-end gap-2">
                  <button
                    onClick={() => router.push(`/company/campaigns/${camp.id}`)}
                    className="px-6 py-3 bg-gradient-to-r from-[#0EA5E9] to-[#38BDF8] text-white rounded-lg hover:shadow-lg transition-all flex items-center gap-2 whitespace-nowrap font-medium"
                  >
                    {t("myCampaigns.actions.viewDetail")}<ArrowRight className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => router.push(`/company/campaigns/new?campaignId=${camp.id}`)}
                    className="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-2 whitespace-nowrap font-medium"
                  >
                    <Edit className="w-5 h-5" />{t("myCampaigns.actions.edit")}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}