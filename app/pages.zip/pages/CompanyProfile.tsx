"use client";

import { useRouter } from "next/navigation";
import { useUser, Company } from "@/app/context/UserContext";
import {
  ArrowLeft, Star, Sparkles, Building2, DollarSign, Target,
  Award, Users, Mail, Briefcase, BadgeCheck, TrendingUp, CheckCircle2,
} from "lucide-react";
import { useTranslation } from "react-i18next";

export default function CompanyProfile() {
  const router = useRouter();
  const { currentUser, campaigns } = useUser();
  const { t } = useTranslation();
  const company = currentUser as Company;

  if (!company) {
    return (
      <main className="flex-1 overflow-y-auto p-8">
        <p className="text-center text-gray-600">{t("companyProfile.notFound")}</p>
      </main>
    );
  }

  const companyCampaigns = campaigns.filter(
    (c) => c.companyId === company.id && c.status === "active"
  );

  const stats = [
    {
      title: t("companyProfile.stats.rating"),
      value: company.rating > 0 ? company.rating.toFixed(1) : t("companyProfile.notAvailable"),
      icon: Star,
      card: "bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8]",
      iconBg: "bg-white/20",
      iconClass: "fill-white",
    },
    {
      title: t("companyProfile.stats.activeCampaigns"),
      value: `${companyCampaigns.length}`,
      icon: Briefcase,
      card: "bg-gradient-to-br from-[#F7EE63] to-[#FCD34D]",
      iconBg: "bg-white/20",
      iconClass: "",
    },
    {
      title: t("companyProfile.stats.collaborations"),
      value: `${company.reviews?.length || 0}`,
      icon: Users,
      card: "bg-gradient-to-br from-green-500 to-emerald-500",
      iconBg: "bg-white/20",
      iconClass: "",
    },
  ];

  return (
    <main className="flex-1 overflow-y-auto">
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="px-8 py-4">
          <button onClick={() => router.back()} className="flex items-center gap-2 text-gray-600 hover:text-[#0EA5E9] transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">{t("common.back")}</span>
          </button>
        </div>
      </div>

      <div className="p-8 max-w-7xl mx-auto">
        {/* Header card */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-6">
          <div className="h-56 relative overflow-hidden">
            <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?w=1080" alt={t("companyProfile.coverAlt")} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-b from-[#0EA5E9]/35 via-[#0EA5E9]/15 to-[#0B1324]/65" />
            <button
              onClick={() => router.push("/register/company")}
              className="absolute top-4 right-4 px-5 py-2.5 rounded-xl flex items-center gap-2 transition-all shadow-2xl bg-white/95 text-[#0EA5E9] hover:bg-white border-2 border-white/50"
            >
              <Sparkles className="w-4 h-4" />
              <span className="font-bold text-sm">{t("companyProfile.editProfile")}</span>
            </button>
          </div>

          <div className="p-8">
            <div className="flex flex-col md:flex-row gap-8 items-start">
              <div className="relative -mt-24 flex-shrink-0">
                <img src={company.logo} alt={company.name} className="w-44 h-44 rounded-[2rem] object-cover border-4 border-white shadow-2xl ring-4 ring-white bg-white" />
                <div className="absolute -bottom-3 -right-3 w-14 h-14 bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8] rounded-full flex items-center justify-center border-4 border-white shadow-2xl">
                  <Building2 className="w-7 h-7 text-white" />
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <h1 className="text-4xl font-black text-[#1F2937] mb-2">{company.name}</h1>
                <p className="text-xl font-bold text-[#0EA5E9] mb-3 flex items-center gap-2">
                  <Building2 className="w-6 h-6" />{company.sector}
                </p>
                <p className="text-gray-600 text-lg leading-relaxed max-w-3xl mb-6">{company.description}</p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {stats.map((stat) => {
                    const Icon = stat.icon;
                    return (
                      <div key={stat.title} className={`${stat.card} text-white rounded-2xl p-5 shadow-xl`}>
                        <div className="flex items-center gap-3 mb-2">
                          <div className={`w-10 h-10 ${stat.iconBg} rounded-lg flex items-center justify-center`}>
                            <Icon className={`w-6 h-6 ${stat.iconClass}`} />
                          </div>
                          <p className="text-3xl font-black">{stat.value}</p>
                        </div>
                        <p className="text-sm font-semibold text-white/90">{stat.title}</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Building2 className="w-6 h-6 text-[#0EA5E9]" />{t("companyProfile.aboutCompany")}
              </h2>
              <p className="text-gray-700 text-sm leading-relaxed">{company.description}</p>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Target className="w-6 h-6 text-[#0EA5E9]" />{t("companyProfile.collaborationObjectives")}
              </h2>
              {!company.objectives || company.objectives.length === 0 ? (
                <div className="rounded-xl bg-[#F3F4F6] p-4 text-sm text-gray-500">{t("companyProfile.noObjectives")}</div>
              ) : (
                <div className="space-y-3">
                  {company.objectives.map((objective, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-gradient-to-r from-[#0EA5E9]/5 to-transparent rounded-lg border-l-4 border-[#0EA5E9]">
                      <CheckCircle2 className="w-5 h-5 text-[#0EA5E9] flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-gray-700 font-medium">{objective}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {companyCampaigns.length > 0 && (
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <TrendingUp className="w-6 h-6 text-[#0EA5E9]" />{t("companyProfile.availableCampaigns")} ({companyCampaigns.length})
                </h2>
                <div className="space-y-4">
                  {companyCampaigns.map((campaign) => (
                    <div key={campaign.id} className="p-4 border-2 border-gray-100 rounded-xl hover:border-[#0EA5E9] transition-all hover:shadow-md">
                      <h3 className="font-bold text-[#1F2937] mb-2">{campaign.name}</h3>
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">{campaign.description}</p>
                      <div className="flex items-center justify-between gap-3 flex-wrap">
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-4 h-4 text-green-600" />
                          <span className="text-sm font-bold text-gray-700">{campaign.budget}</span>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {campaign.creatorType?.slice(0, 2).map((type, idx) => (
                            <span key={idx} className="px-2 py-1 bg-[#0EA5E9]/10 text-[#0EA5E9] rounded-lg text-xs font-semibold">{type}</span>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {company.reviews && company.reviews.length > 0 && (
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Star className="w-6 h-6 text-yellow-500 fill-yellow-500" />{t("companyProfile.creatorReviews")} ({company.reviews.length})
                </h2>
                <div className="space-y-4">
                  {company.reviews.map((review) => (
                    <div key={review.id} className="border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="font-bold text-[#1F2937]">{review.from}</p>
                          <p className="text-xs text-gray-500">{review.date}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className={`w-4 h-4 ${i < review.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`} />
                          ))}
                        </div>
                      </div>
                      <p className="text-sm text-gray-700 leading-relaxed">{review.comment}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-[#1F2937]">
                <DollarSign className="w-5 h-5 text-[#0EA5E9]" />{t("companyProfile.budget")}
              </h3>
              <p className="text-2xl font-black bg-gradient-to-r from-[#0EA5E9] to-[#38BDF8] bg-clip-text text-transparent">{company.budget}</p>
              <p className="text-xs text-gray-500 mt-1">{t("companyProfile.monthlyInvestment")}</p>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-[#1F2937]">
                <Briefcase className="w-5 h-5 text-[#0EA5E9]" />{t("companyProfile.industry")}
              </h3>
              <div className="px-4 py-3 bg-gradient-to-r from-[#0EA5E9] to-[#38BDF8] text-white rounded-xl text-center font-bold shadow-md">{company.sector}</div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-[#1F2937]">
                <Mail className="w-5 h-5 text-[#0EA5E9]" />{t("companyProfile.contact")}
              </h3>
              <p className="text-sm text-gray-700 break-all">{company.email}</p>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-lg font-semibold mb-4 text-[#1F2937]">{t("companyProfile.statistics")}</h3>
              <div className="space-y-4">
                {[
                  { icon: Star, iconClass: "text-yellow-500 fill-yellow-500", label: t("companyProfile.averageRating"), value: company.rating > 0 ? `${company.rating.toFixed(1)}/5.0` : t("companyProfile.notAvailable") },
                  { icon: Users, iconClass: "text-[#0EA5E9]", label: t("companyProfile.collaborations"), value: company.reviews?.length || 0 },
                  { icon: TrendingUp, iconClass: "text-green-500", label: t("companyProfile.activeCampaigns"), value: companyCampaigns.length },
                  { icon: BadgeCheck, iconClass: "text-cyan-600", label: t("companyProfile.status"), value: t("companyProfile.verified") },
                ].map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Icon className={`w-4 h-4 ${item.iconClass}`} />
                        <span className="text-sm font-medium text-gray-700">{item.label}</span>
                      </div>
                      <span className="text-sm font-bold text-[#1F2937]">{item.value}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}