"use client";

import { useUser, Creator } from "@/app/context/UserContext";
import { useRouter } from "next/navigation";
import { FileText, Building2, Calendar, ArrowRight } from "lucide-react";
import { useTranslation } from "react-i18next";

export default function MyApplications() {
  const { applications, campaigns, currentUser } = useUser();
  const router = useRouter();
  const { t } = useTranslation();
  const creator = currentUser as Creator;

  const myApplications = applications.filter((a) => a.creatorId === creator?.id);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "sent": return "bg-blue-100 text-blue-700";
      case "reviewing": return "bg-yellow-100 text-yellow-700";
      case "accepted": return "bg-green-100 text-green-700";
      case "rejected": return "bg-red-100 text-red-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const getStatusText = (status: string) => {
    const map: Record<string, string> = {
      sent: t("applications.status.sent"),
      reviewing: t("applications.status.reviewing"),
      accepted: t("applications.status.accepted"),
      rejected: t("applications.status.rejected"),
    };
    return map[status] || status;
  };

  return (
    <div className="flex-1 p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t("applications.title")}</h1>
        <p className="text-gray-600">{t("myApplications.subtitle")}</p>
      </div>

      {myApplications.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
          <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">{t("applications.noApplications")}</h2>
          <p className="text-gray-600 mb-6">{t("myApplications.emptyDescription")}</p>
          <button onClick={() => router.push("/creator/campaigns")} className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
            {t("myApplications.viewAvailableCampaigns")}
          </button>
        </div>
      ) : (
        <div className="grid gap-6">
          {myApplications.map((application) => {
            const campaign = campaigns.find((c) => c.id === application.campaignId);
            if (!campaign) return null;
            return (
              <div key={application.id} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                <div className="flex flex-col md:flex-row justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h2 className="text-2xl font-bold text-gray-900 mb-1">{campaign.name}</h2>
                        <div className="flex items-center gap-2 text-gray-600">
                          <Building2 className="w-4 h-4" />
                          <span>{campaign.companyName}</span>
                        </div>
                      </div>
                      <span className={`px-4 py-2 rounded-full text-sm font-semibold ${getStatusColor(application.status)}`}>
                        {getStatusText(application.status)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-600 mb-4">
                      <Calendar className="w-4 h-4" />
                      <span>{t("applications.appliedOn")} {application.appliedDate}</span>
                    </div>
                    <p className="text-gray-700 line-clamp-2">{campaign.description}</p>
                  </div>
                  <div className="flex md:flex-col justify-end md:justify-center items-end gap-2">
                    <button
                      onClick={() => router.push(`/creator/applications/${application.id}`)}
                      className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center gap-2 whitespace-nowrap"
                    >
                      {t("myApplications.viewDetail")}
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}