"use client";

import { useUser, MATCH_CREATOR_SYSTEM } from "@/app/context/UserContext";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import { MessageSquare, Send, Search, Clock, CheckCircle, ShieldCheck } from "lucide-react";
import { useState, useEffect, useRef } from "react";

export default function CompanyMessages() {
  const { t } = useTranslation();
  const { currentUser, conversations, messages, creators, companies, addMessage, markAsRead } = useUser();
  const router = useRouter();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [messageText, setMessageText] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const getConversationsWithDetails = () => {
    return conversations
      .filter((conv) => conv.participants.some((p) => p.id === currentUser?.id))
      .map((conv) => {
        const otherParticipant = conv.participants.find((p) => p.id !== currentUser?.id);
        if (!otherParticipant) return { ...conv, otherUser: null };
        if (otherParticipant.id === MATCH_CREATOR_SYSTEM.id) {
          return { ...conv, otherUser: { id: MATCH_CREATOR_SYSTEM.id, name: MATCH_CREATOR_SYSTEM.name, type: "system" as const, displayName: MATCH_CREATOR_SYSTEM.name, avatar: MATCH_CREATOR_SYSTEM.avatar, isSystem: true } };
        }
        let otherUser: any = otherParticipant.type === "creator" ? creators.find((c) => c.id === otherParticipant.id) : companies.find((c) => c.id === otherParticipant.id);
        if (!otherUser) otherUser = { id: otherParticipant.id, name: otherParticipant.name, avatar: otherParticipant.avatar };
        return {
          ...conv,
          otherUser: {
            ...otherUser, type: otherParticipant.type,
            displayName: otherParticipant.type === "creator" ? (otherUser as any).publicName || otherUser.name : otherUser.name,
            avatar: otherParticipant.type === "creator" ? (otherUser as any).avatar : (otherUser as any).logo || otherParticipant.avatar,
            isSystem: false,
          },
        };
      });
  };

  const conversationsWithDetails = getConversationsWithDetails();
  const selectedConversation = conversationsWithDetails.find((c) => c.id === selectedConversationId);
  const conversationMessages = messages.filter((m) => m.conversationId === selectedConversationId);
  const filteredConversations = conversationsWithDetails.filter((conv) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return conv.otherUser?.displayName?.toLowerCase().includes(query) || conv.lastMessage?.text.toLowerCase().includes(query);
  });

  const handleSendMessage = () => {
    if (!messageText.trim() || !selectedConversationId || !currentUser) return;
    if (selectedConversation?.otherUser?.isSystem) return;
    addMessage({
      id: `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      conversationId: selectedConversationId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: (currentUser as any).logo || (currentUser as any).avatar,
      text: messageText.trim(),
      timestamp: new Date().toISOString(),
      read: false,
    });
    setMessageText("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSendMessage(); }
  };

  useEffect(() => {
    if (selectedConversationId && currentUser) markAsRead(selectedConversationId, currentUser.id);
  }, [selectedConversationId, currentUser]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [conversationMessages]);

  useEffect(() => {
    if (!selectedConversationId && conversationsWithDetails.length > 0) setSelectedConversationId(conversationsWithDetails[0].id);
  }, [conversationsWithDetails.length]);

  const primaryColor = "#0EA5E9";
  const bubbleGradient = "linear-gradient(to bottom right, #0EA5E9, #38BDF8)";
  const isSystemConversation = selectedConversation?.otherUser?.isSystem === true;

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    if (diff < 24) return date.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
    if (diff < 48) return t("companyMessages.time.yesterday");
    return date.toLocaleDateString("es-ES", { day: "numeric", month: "short" });
  };

  return (
    <main className="flex-1 flex" style={{height: 'calc(100vh - 0px)', overflow: 'hidden'}}>
      {/* Conversations list */}
      <div className="w-96 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-6 border-b border-gray-200">
          <h1 className="text-2xl font-black text-[#1F2937] mb-4 flex items-center gap-2">
            <MessageSquare className="w-7 h-7" style={{ color: primaryColor }} />{t("messages.title")}
          </h1>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder={t("companyMessages.searchPlaceholder")} className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-800 outline-none focus:border-[#0EA5E9] transition-colors" />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {filteredConversations.length === 0 ? (
            <div className="p-8 text-center">
              <MessageSquare className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-gray-500 font-medium">{t("companyMessages.empty.title")}</p>
              <p className="text-gray-400 text-sm mt-1">{t("companyMessages.empty.subtitle")}</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {filteredConversations.map((conv) => (
                <button key={conv.id} onClick={() => setSelectedConversationId(conv.id)} className={`w-full p-4 flex items-start gap-3 hover:bg-gray-50 transition-colors text-left ${selectedConversationId === conv.id ? "bg-gray-50" : ""}`}>
                  <div className="relative flex-shrink-0">
                    <img src={conv.otherUser?.avatar} alt={conv.otherUser?.displayName} className="w-12 h-12 rounded-full object-cover border-2 border-gray-200" />
                    {conv.otherUser?.isSystem && <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white"><ShieldCheck className="w-3 h-3 text-white" /></div>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1">
                      <div className="flex items-center gap-1">
                        <p className="font-bold text-[#1F2937] truncate">{conv.otherUser?.displayName}</p>
                        {conv.otherUser?.isSystem && <CheckCircle className="w-4 h-4 text-blue-500 flex-shrink-0" />}
                      </div>
                      {conv.lastMessage && <span className="text-xs text-gray-500 flex-shrink-0 ml-2">{formatTime(conv.lastMessage.timestamp)}</span>}
                    </div>
                    {conv.lastMessage && <p className="text-sm text-gray-600 truncate">{conv.lastMessage.senderId === currentUser?.id ? t("companyMessages.youPrefix") : ""}{conv.lastMessage.text}</p>}
                    {currentUser && (conv.unreadByUser[currentUser.id] ?? 0) > 0 && (
                      <div className="mt-1 w-5 h-5 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ backgroundColor: primaryColor }}>{conv.unreadByUser[currentUser.id]}</div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 flex flex-col bg-gray-50">
        {selectedConversation && selectedConversation.otherUser ? (
          <>
            <div className="bg-white border-b border-gray-200 p-4 flex items-center gap-3">
              <div className="relative">
                <img src={selectedConversation.otherUser.avatar} alt={selectedConversation.otherUser.displayName} className="w-12 h-12 rounded-full object-cover border-2" style={{ borderColor: isSystemConversation ? "#3B82F6" : primaryColor }} />
                {isSystemConversation && <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white"><ShieldCheck className="w-3 h-3 text-white" /></div>}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h2 className="font-bold text-[#1F2937]">{selectedConversation.otherUser.displayName}</h2>
                  {isSystemConversation && <CheckCircle className="w-4 h-4 text-blue-500" />}
                </div>
                <p className="text-sm text-gray-500">
                  {isSystemConversation ? t("companyMessages.chat.systemSubtitle") : selectedConversation.otherUser.type === "creator" ? t("companyMessages.chat.creatorType") : t("companyMessages.chat.companyType")}
                </p>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {conversationMessages.length === 0 ? (
                <div className="text-center py-12">
                  <div className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ background: `linear-gradient(to bottom right, ${primaryColor}20, #38BDF820)` }}>
                    <MessageSquare className="w-10 h-10" style={{ color: primaryColor }} />
                  </div>
                  <p className="text-gray-600 font-medium">{t("companyMessages.chat.emptyTitle")}</p>
                  <p className="text-gray-400 text-sm mt-1">{t("companyMessages.chat.emptySubtitle")}</p>
                </div>
              ) : (
                <>
                  {conversationMessages.map((message) => {
                    const isMyMessage = message.senderId === currentUser?.id;
                    const isSystemMessage = message.senderId === MATCH_CREATOR_SYSTEM.id;
                    return (
                      <div key={message.id} className={`flex items-end gap-2 ${isMyMessage ? "flex-row-reverse" : "flex-row"}`}>
                        <div className="relative">
                          <img src={message.senderAvatar} alt={message.senderName} className="w-8 h-8 rounded-full object-cover border-2 border-gray-200 flex-shrink-0" />
                          {isSystemMessage && <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white"><CheckCircle className="w-3 h-3 text-white fill-current" /></div>}
                        </div>
                        <div className={`max-w-md flex flex-col ${isMyMessage ? "items-end" : "items-start"}`}>
                          {isSystemMessage && <div className="flex items-center gap-1 mb-1"><span className="text-xs font-bold text-blue-600">MatchCreator</span><CheckCircle className="w-3 h-3 text-blue-500" /></div>}
                          <div className="px-4 py-2.5 shadow-sm" style={{ background: isSystemMessage ? "linear-gradient(to bottom right, #3B82F6, #60A5FA)" : isMyMessage ? bubbleGradient : "#FFFFFF", borderRadius: isMyMessage ? "1rem 1rem 0 1rem" : "1rem 1rem 1rem 0", border: !isMyMessage && !isSystemMessage ? "1px solid #E5E7EB" : "none" }}>
                            <p className="text-sm leading-relaxed whitespace-pre-wrap break-words" style={{ color: isMyMessage || isSystemMessage ? "white" : "#1F2937" }}>{message.text}</p>
                          </div>
                          <span className="text-xs text-gray-400 mt-1 px-1 flex items-center gap-1"><Clock className="w-3 h-3" />{formatTime(message.timestamp)}</span>
                        </div>
                      </div>
                    );
                  })}
                  <div ref={messagesEndRef} />
                </>
              )}
            </div>

            <div className="bg-white border-t border-gray-200 p-4">
              {isSystemConversation ? (
                <div className="flex items-center justify-center gap-2 py-3 text-sm text-gray-400 bg-gray-50 rounded-2xl border border-gray-200">
                  <ShieldCheck className="w-4 h-4 text-blue-400" />{t("companyMessages.chat.systemReadOnly")}
                </div>
              ) : (
                <div className="flex items-end gap-3">
                  <textarea value={messageText} onChange={(e) => setMessageText(e.target.value)} onKeyPress={handleKeyPress} placeholder={t("messages.typeMessage")} rows={1} className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl resize-none outline-none focus:border-[#0EA5E9] transition-colors text-sm text-gray-800" style={{ minHeight: "44px", maxHeight: "120px" }} />
                  <button onClick={handleSendMessage} disabled={!messageText.trim()} className="px-5 py-3 rounded-2xl text-white font-bold flex items-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg" style={{ background: messageText.trim() ? bubbleGradient : "#D1D5DB" }}>
                    <Send className="w-4 h-4" />{t("common.send")}
                  </button>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="w-24 h-24 rounded-full mx-auto mb-6 flex items-center justify-center" style={{ background: `linear-gradient(to bottom right, ${primaryColor}20, #38BDF820)` }}>
                <MessageSquare className="w-12 h-12" style={{ color: primaryColor }} />
              </div>
              <h3 className="text-xl font-bold text-[#1F2937] mb-2">{t("companyMessages.selectConversation.title")}</h3>
              <p className="text-gray-500">{t("companyMessages.selectConversation.subtitle")}</p>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}