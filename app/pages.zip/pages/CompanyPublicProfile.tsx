"use client";

import { useParams, useRouter } from "next/navigation";
import { useUser } from "@/app/context/UserContext";
import { useTranslation } from "react-i18next";
import {
  ArrowLeft, Star, Building2, Award, Mail, Briefcase,
  Target, DollarSign, Users, TrendingUp, CheckCircle2,
} from "lucide-react";

export default function CompanyPublicProfile() {
  const { t } = useTranslation();
  const { id } = useParams();
  const router = useRouter();
  const { companies, campaigns, userType } = useUser();

  const company = companies.find((c) => c.id === id);

  if (!company) {
    return (
      <main className="flex-1 overflow-y-auto p-8">
        <p className="text-center text-gray-600">{t("companyPublicProfile.notFound")}</p>
      </main>
    );
  }

  const companyCampaigns = campaigns.filter((c) => c.companyId === company.id && c.status === "active");

  // La ruta de campañas depende del tipo de usuario
  const campaignsRoute = userType === "creator" ? "/campaigns" : "/company/campaigns";
  const campaignDetailRoute = (campaignId: string) =>
    userType === "creator" ? `/campaigns/${campaignId}` : `/company/campaigns/${campaignId}`;

  return (
    <main className="flex-1 overflow-y-auto">
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10 px-8 py-4">
        <button onClick={() => router.back()} className="flex items-center gap-2 text-gray-600 hover:text-[#0EA5E9] transition-colors">
          <ArrowLeft className="w-5 h-5" /><span className="font-medium">{t("common.back")}</span>
        </button>
      </div>

      <div className="p-8 max-w-7xl mx-auto">
        {/* Header card */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-6">
          <div className="h-56 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-[#0EA5E9] via-[#06B6D4] to-[#38BDF8]" />
            <div className="absolute inset-0 opacity-20">
              <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full -translate-x-1/2 -translate-y-1/2" />
              <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full translate-x-1/2 translate-y-1/2" />
            </div>
          </div>

          <div className="p-8">
            <div className="flex flex-col md:flex-row gap-8 items-start">
              <div className="relative -mt-24 flex-shrink-0">
                <img src={company.logo} alt={company.name} className="w-44 h-44 rounded-2xl object-cover border-4 border-white shadow-2xl ring-4 ring-white bg-white" />
                <div className="absolute -bottom-3 -right-3 w-14 h-14 bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8] rounded-full flex items-center justify-center border-4 border-white shadow-2xl group">
                  <Award className="w-7 h-7 text-white" />
                  <div className="absolute bottom-full right-0 mb-2 px-3 py-2 bg-gray-900 text-white text-xs font-semibold rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">{t("companyPublicProfile.verifiedCompany")}</div>
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <h1 className="text-4xl font-black text-[#1F2937] mb-2">{company.name}</h1>
                <p className="text-xl font-bold text-[#0EA5E9] mb-3 flex items-center gap-2"><Building2 className="w-6 h-6" />{company.sector}</p>
                <p className="text-gray-600 text-lg leading-relaxed max-w-3xl mb-6">{company.description}</p>

                <div className="grid grid-cols-3 gap-4">
                  {[
                    { gradient: "from-[#0EA5E9] to-[#38BDF8]", icon: <Star className="w-6 h-6" />, value: company.rating.toFixed(1), label: t("companyPublicProfile.stats.rating") },
                    { gradient: "from-[#F7EE63] to-[#FCD34D]", icon: <Briefcase className="w-6 h-6" />, value: companyCampaigns.length, label: t("companyPublicProfile.stats.activeCampaigns") },
                    { gradient: "from-green-500 to-emerald-500", icon: <Users className="w-6 h-6" />, value: company.reviews?.length || 0, label: t("companyPublicProfile.stats.collaborations") },
                  ].map((stat, i) => (
                    <div key={i} className={`bg-gradient-to-br ${stat.gradient} text-white rounded-2xl p-5 shadow-xl hover:scale-105 transition-transform`}>
                      <div className="flex items-center gap-3 mb-2"><div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">{stat.icon}</div><p className="text-3xl font-black">{stat.value}</p></div>
                      <p className="text-sm font-semibold text-white/90">{stat.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Building2 className="w-6 h-6 text-[#0EA5E9]" />{t("companyPublicProfile.sections.about")}
              </h2>
              <p className="text-gray-700 text-sm leading-relaxed">{company.description}</p>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Target className="w-6 h-6 text-[#0EA5E9]" />{t("companyPublicProfile.sections.objectives")}
              </h2>
              {!company.objectives || company.objectives.length === 0 ? (
                <div className="rounded-xl bg-[#F3F4F6] p-4 text-sm text-gray-500">{t("companyPublicProfile.objectives.empty")}</div>
              ) : (
                <div className="space-y-3">
                  {company.objectives.map((obj, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-gradient-to-r from-[#0EA5E9]/5 to-transparent rounded-lg border-l-4 border-[#0EA5E9]">
                      <CheckCircle2 className="w-5 h-5 text-[#0EA5E9] flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-gray-700 font-medium">{obj}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {companyCampaigns.length > 0 && (
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <TrendingUp className="w-6 h-6 text-[#0EA5E9]" />{t("companyPublicProfile.sections.activeCampaigns", { count: companyCampaigns.length })}
                </h2>
                <div className="space-y-4">
                  {companyCampaigns.map((campaign) => (
                    <div key={campaign.id} onClick={() => router.push(campaignDetailRoute(campaign.id))} className="p-4 border-2 border-gray-100 rounded-xl hover:border-[#0EA5E9] transition-all cursor-pointer group hover:shadow-md">
                      <h3 className="font-bold text-[#1F2937] mb-2 group-hover:text-[#0EA5E9] transition-colors">{campaign.name}</h3>
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">{campaign.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2"><DollarSign className="w-4 h-4 text-green-600" /><span className="text-sm font-bold text-gray-700">{campaign.budget}</span></div>
                        <div className="flex flex-wrap gap-1">
                          {campaign.creatorType.slice(0, 2).map((type, idx) => (
                            <span key={idx} className="px-2 py-1 bg-[#0EA5E9]/10 text-[#0EA5E9] rounded-lg text-xs font-semibold">{type}</span>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {company.reviews && company.reviews.length > 0 && (
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Star className="w-6 h-6 text-yellow-500 fill-yellow-500" />{t("companyPublicProfile.sections.reviews", { count: company.reviews.length })}
                </h2>
                <div className="space-y-4">
                  {company.reviews.map((review) => (
                    <div key={review.id} className="border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                      <div className="flex items-start justify-between mb-2">
                        <div><p className="font-bold text-[#1F2937]">{review.from}</p><p className="text-xs text-gray-500">{review.date}</p></div>
                        <div className="flex items-center gap-1">{[...Array(5)].map((_, i) => <Star key={i} className={`w-4 h-4 ${i < review.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`} />)}</div>
                      </div>
                      <p className="text-sm text-gray-700 leading-relaxed">{review.comment}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-[#1F2937]"><DollarSign className="w-5 h-5 text-[#0EA5E9]" />{t("companyPublicProfile.sidebar.budget")}</h3>
              <p className="text-2xl font-black bg-gradient-to-r from-[#0EA5E9] to-[#38BDF8] bg-clip-text text-transparent">{company.budget}</p>
              <p className="text-xs text-gray-500 mt-1">{t("companyPublicProfile.sidebar.budgetHint")}</p>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-[#1F2937]"><Briefcase className="w-5 h-5 text-[#0EA5E9]" />{t("companyPublicProfile.sidebar.industry")}</h3>
              <div className="px-4 py-3 bg-gradient-to-r from-[#0EA5E9] to-[#38BDF8] text-white rounded-xl text-center font-bold shadow-md">{company.sector}</div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-[#1F2937]"><Mail className="w-5 h-5 text-[#0EA5E9]" />{t("companyPublicProfile.sidebar.contact")}</h3>
              <p className="text-sm text-gray-700 break-all">{company.email}</p>
            </div>

            {companyCampaigns.length > 0 && (
              <div className="bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8] rounded-2xl shadow-xl p-6 text-white">
                <div className="text-center">
                  <Briefcase className="w-12 h-12 mx-auto mb-4 opacity-90" />
                  <h3 className="text-lg font-bold mb-2">{t("companyPublicProfile.cta.title", { count: companyCampaigns.length })}</h3>
                  <p className="text-sm text-white/90 mb-4">{t("companyPublicProfile.cta.subtitle")}</p>
                  <button onClick={() => router.push(campaignsRoute)} className="w-full px-6 py-3 bg-white text-[#0EA5E9] rounded-xl font-bold hover:shadow-2xl transition-all hover:scale-105">
                    {t("companyPublicProfile.cta.button")}
                  </button>
                </div>
              </div>
            )}

            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-lg font-semibold mb-4 text-[#1F2937]">{t("companyPublicProfile.sidebar.statsTitle")}</h3>
              <div className="space-y-4">
                {[
                  { icon: <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />, label: t("companyPublicProfile.sidebar.avgRating"), value: `${company.rating.toFixed(1)}/5.0` },
                  { icon: <Users className="w-4 h-4 text-[#0EA5E9]" />, label: t("companyPublicProfile.sidebar.collaborations"), value: company.reviews?.length || 0 },
                  { icon: <TrendingUp className="w-4 h-4 text-green-500" />, label: t("companyPublicProfile.sidebar.activeCampaigns"), value: companyCampaigns.length },
                ].map((item, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2">{item.icon}<span className="text-sm font-medium text-gray-700">{item.label}</span></div>
                    <span className="text-sm font-bold text-[#1F2937]">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}