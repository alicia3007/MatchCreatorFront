"use client";

import { useParams, useRouter } from "next/navigation";
import { useUser, Creator } from "@/app/context/UserContext";
import {
  ArrowLeft, Sparkles, Building2, DollarSign, Calendar,
  Target, CheckCircle, Users, TrendingUp, Award, ListChecks,
  Package, Instagram, Youtube, Twitter, Facebook, ChevronDown,
} from "lucide-react";
import { useState } from "react";
import { useTranslation } from "react-i18next";

export default function CampaignDetail() {
  const { id } = useParams();
  const router = useRouter();
  const { campaigns, applications, addApplication, currentUser } = useUser();
  const [applied, setApplied] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const { t, i18n } = useTranslation();

  const campaign = campaigns.find((c) => c.id === id);
  const creator = currentUser as Creator;
  const hasApplied = applications.some((a) => a.campaignId === id && a.creatorId === creator?.id);

  if (!campaign) {
    return (
      <main className="flex-1 overflow-y-auto p-8">
        <p className="text-center text-gray-600">{t("campaignDetail.notFound")}</p>
      </main>
    );
  }

  const handleApply = () => {
    if (!creator) return;
    const newApplication = {
      id: `app-${Date.now()}`,
      campaignId: campaign.id,
      creatorId: creator.id,
      creatorName: creator.name,
      status: "sent" as const,
      appliedDate: new Date().toISOString().split("T")[0],
    };
    addApplication(newApplication);
    setApplied(true);
  };

  const getPlatformIcon = (platform: string) => {
    const p = platform.toLowerCase();
    if (p.includes("instagram")) return <Instagram className="w-4 h-4" />;
    if (p.includes("youtube")) return <Youtube className="w-4 h-4" />;
    if (p.includes("tiktok")) return <span className="font-bold text-sm">TT</span>;
    if (p.includes("twitter") || p.includes("x.com")) return <Twitter className="w-4 h-4" />;
    if (p.includes("facebook")) return <Facebook className="w-4 h-4" />;
    return <TrendingUp className="w-4 h-4" />;
  };

  const c = campaign as any;
  const deliverables: any[] = c.deliverables || [];
  const bannerImage: string | null = c.bannerImage || null;
  const locale = i18n.language?.startsWith("es") ? "es-ES" : "en-US";
  const coverSrc = bannerImage || "https://images.unsplash.com/photo-1676282827533-d6058df56a69?w=1080";

  const isApplied = hasApplied || applied;

  const fallbackDeliverables = [
    { text: t("campaignDetail.fallback.createAuthenticContentTitle") },
    { text: t("campaignDetail.fallback.publishOnPlatformsTitle") },
    { text: t("campaignDetail.fallback.reportMetricsTitle") },
    { text: t("campaignDetail.fallback.maintainCommunicationTitle") },
  ];
  const deliverableItems = deliverables.length > 0 ? deliverables : fallbackDeliverables;

  return (
    <main className="flex-1 overflow-y-auto bg-gray-100">

      {/* ── Sticky top bar ── */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-20">
        <div className="px-8 py-3 flex items-center justify-between">
          <button
            onClick={() => router.push("/creator/campaigns")}
            className="flex items-center gap-2 text-gray-500 hover:text-[#7C3AED] transition-colors text-sm font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            {t("campaignDetail.backToCampaigns")}
          </button>
          {isApplied && (
            <span className="flex items-center gap-1.5 text-green-600 text-sm font-semibold">
              <CheckCircle className="w-4 h-4 fill-green-600" />
              {t("campaignDetail.alreadyApplied")}
            </span>
          )}
        </div>
      </div>

      <div className="px-8 py-8 space-y-5">

        {/* ══ HERO ══ */}
        <div className="bg-[#1F2937] rounded-2xl overflow-hidden shadow-lg">
          <div className="h-56 relative">
            <img src={coverSrc} alt="" className="w-full h-full object-cover opacity-35" />
            <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, transparent, #1F2937 90%)" }} />
            {campaign.creatorType && campaign.creatorType.length > 0 && (
              <div className="absolute top-4 right-4 flex flex-wrap gap-2 max-w-xs">
                {campaign.creatorType.map((type, i) => (
                  <span key={i} className="px-4 py-2 bg-gradient-to-r from-[#7C3AED] to-[#A78BFA] text-white text-sm font-bold rounded-full shadow-lg">
                    {type}
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="px-10 pb-9 -mt-8 relative flex flex-col gap-4">
            {/* Status pill */}
            <div
              className="inline-flex items-center gap-1.5 self-start px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider"
              style={{ background: "rgba(74,222,128,0.15)", border: "1px solid rgba(74,222,128,0.3)", color: "#4ADE80" }}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#4ADE80]" />
              {t("campaignDetail.activeCampaign")}
            </div>

            <h1 className="text-4xl font-extrabold text-white leading-tight tracking-tight">
              {campaign.name}
            </h1>

            <button
              onClick={() => router.push(`/companies/${campaign.companyId}`)}
              className="inline-flex items-center gap-2 group w-fit"
            >
              <Building2 className="w-4 h-4 text-white/40" />
              <span className="text-base text-white/55 group-hover:text-white/80 transition-colors">
                {campaign.companyName}
              </span>
            </button>

            {/* KPIs inline */}
            <div
              className="flex flex-wrap gap-x-10 gap-y-4 pt-5"
              style={{ borderTop: "1px solid rgba(255,255,255,0.1)" }}
            >
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-white/45 text-sm">
                  <DollarSign className="w-4 h-4" />
                  {t("campaignDetail.paymentOffered")}
                </div>
                <span className="text-white font-bold text-lg">{campaign.budget}</span>
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-white/45 text-sm">
                  <Calendar className="w-4 h-4" />
                  {t("campaignDetail.duration")}
                </div>
                <span className="text-white font-bold text-lg">
                  {new Date(campaign.startDate).toLocaleDateString(locale, { day: "2-digit", month: "short" })}
                  {" – "}
                  {new Date(campaign.endDate).toLocaleDateString(locale, { day: "2-digit", month: "short" })}
                </span>
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-white/45 text-sm">
                  <Users className="w-4 h-4" />
                  {t("campaigns.applicants")}
                </div>
                <span className="text-white font-bold text-lg">{campaign.applicants.length}</span>
              </div>

              {/* Plataformas */}
              <div className="flex flex-col gap-1">
                <span className="text-white/45 text-sm">{t("campaignDetail.requiredPlatforms")}</span>
                <div className="flex flex-wrap gap-2 mt-0.5">
                  {campaign.socialPlatform.map((platform, i) => (
                    <span
                      key={i}
                      className="inline-flex items-center gap-1.5 text-white/80 text-sm font-medium"
                      style={{ padding: "4px 12px", borderRadius: "4px", background: "rgba(255,255,255,0.1)" }}
                    >
                      {getPlatformIcon(platform)}
                      {platform}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Botón postular */}
            {!isApplied ? (
              <button
                onClick={handleApply}
                className="w-full py-4 rounded-xl font-black text-lg text-white shadow-xl hover:opacity-90 hover:scale-[1.01] transition-all active:scale-95 flex items-center justify-center gap-2 mt-1"
                style={{ background: "#7C3AED" }}
              >
                <Sparkles className="w-5 h-5 text-white/80" />
                {t("campaignDetail.applyNow")}
              </button>
            ) : (
              <button
                onClick={() => router.push("/creator/applications")}
                className="w-full py-4 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold text-lg transition-all flex items-center justify-center gap-2 mt-1"
              >
                <CheckCircle className="w-5 h-5" />
                {t("campaignDetail.viewMyApplications")}
              </button>
            )}
          </div>
        </div>

        {/* ══ Descripción + Objetivo + Requisitos + Entregables en grid ══ */}
        <div className="grid grid-cols-2 gap-5">

          {/* Descripción + Objetivo */}
          <div className="bg-white rounded-2xl shadow-sm p-7">
            <h2 className="text-base font-bold text-[#1F2937] mb-3 flex items-center gap-2">
              <Package className="w-4 h-4 text-[#7C3AED]" />
              {t("campaignDetail.campaignDescription")}
            </h2>
            <p className="text-gray-600 text-base leading-relaxed">{campaign.description}</p>

            {campaign.objective && (
              <div className="mt-5 pt-5 border-t border-gray-100">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-4 h-4 text-[#7C3AED]" />
                  <span className="text-base font-bold text-[#1F2937]">{t("campaignDetail.collaborationObjective")}</span>
                </div>
                <p className="text-gray-600 text-base leading-relaxed">{campaign.objective}</p>
              </div>
            )}
          </div>

          {/* Requisitos */}
          <div className="bg-white rounded-2xl shadow-sm p-7">
            <h2 className="text-base font-bold text-[#1F2937] mb-4 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-[#7C3AED]" />
              {t("campaignDetail.requirements")}
            </h2>
            <ul className="space-y-2">
              {campaign.requirements.slice(0, showDetails ? undefined : 5).map((req, i) => (
                <li
                  key={i}
                  className="flex items-start gap-3 p-3 rounded-lg bg-gray-50"
                  style={{ borderLeft: "3px solid #7C3AED" }}
                >
                  <CheckCircle className="w-4 h-4 text-[#7C3AED] flex-shrink-0 mt-0.5" />
                  <span className="text-gray-900 text-base leading-relaxed">{req}</span>
                </li>
              ))}
            </ul>
            {campaign.requirements.length > 5 && (
              <button
                onClick={() => setShowDetails(!showDetails)}
                className="mt-3 flex items-center gap-1 text-[#7C3AED] text-sm font-semibold hover:underline"
              >
                {showDetails ? "Ver menos" : `Ver ${campaign.requirements.length - 5} más`}
                <ChevronDown className={`w-4 h-4 transition-transform ${showDetails ? "rotate-180" : ""}`} />
              </button>
            )}
          </div>

        </div>

        {/* ══ Qué hay que hacer — full width ══ */}
        <div className="bg-white rounded-2xl shadow-sm p-7">
          <h2 className="text-base font-bold text-[#1F2937] mb-4 flex items-center gap-2">
            <ListChecks className="w-4 h-4 text-[#7C3AED]" />
            {t("campaignDetail.whatYouNeedToDo")}
          </h2>
          <div className="grid grid-cols-2 gap-2">
            {deliverableItems.map((d: any, i: number) => (
              <div
                key={i}
                className="flex items-start gap-3 p-3.5 rounded-lg"
                style={{ background: "#F5F3FF", borderLeft: "3px solid #7C3AED" }}
              >
                <CheckCircle className="w-4 h-4 text-[#7C3AED] flex-shrink-0 mt-0.5" />
                <span className="text-gray-900 text-base leading-relaxed">{d.text || d}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ══ Consejo ══ */}
        <div className="rounded-2xl p-6 flex items-start gap-3 mb-2" style={{ background: "#7C3AED" }}>
          <Award className="w-5 h-5 text-white flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-white text-base mb-0.5">{t("campaignDetail.creatorConnectTip")}</h3>
            <p className="text-sm text-white/80 leading-relaxed">{t("campaignDetail.creatorConnectTipDesc")}</p>
          </div>
        </div>

      </div>
    </main>
  );
}