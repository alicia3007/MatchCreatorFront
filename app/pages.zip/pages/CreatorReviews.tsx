"use client";

import { useState } from "react";
import { useUser, Creator, Company } from "@/app/context/UserContext";
import { Star, MessageSquare, Building2, CheckCircle, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";

export default function CreatorReviews() {
  const { t } = useTranslation();
  const { currentUser, applications, campaigns, companies, creators, addReview } = useUser();
  const creator = currentUser as Creator;

  const [activeTab, setActiveTab] = useState<"received" | "write">("received");
  const [selectedCompanyId, setSelectedCompanyId] = useState<string | null>(null);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const currentCreator = creators.find((c) => c.id === creator?.id) || creator;
  const averageRating = currentCreator?.rating || 0;
  const reviews = currentCreator?.reviews || [];

  const acceptedApplications = applications.filter(
  (app) => app.creatorId === creator?.id && 
  (app.status === "accepted" || app.status === "confirmed")
);

  const collaboratedCompanies = acceptedApplications
    .map((app) => {
      const campaign = campaigns.find((c) => c.id === app.campaignId);
      const company = companies.find((c) => c.id === campaign?.companyId);
      return company;
    })
    .filter(
      (company, index, self) => company && self.findIndex((c) => c?.id === company.id) === index
    ) as Company[];

  const hasReviewedCompany = (companyId: string) => {
    const company = companies.find((c) => c.id === companyId);
    return company?.reviews.some((r) => r.from === creator.publicName) || false;
  };

  const handleSubmitReview = () => {
    if (!selectedCompanyId || rating === 0 || !comment.trim()) return;
    setSubmitting(true);

    addReview(selectedCompanyId, "company", {
      id: `rev-${Date.now()}`,
      from: creator.publicName,
      rating,
      comment: comment.trim(),
      date: new Date().toISOString().split("T")[0],
    });

    setTimeout(() => {
      setSelectedCompanyId(null);
      setRating(0);
      setComment("");
      setSubmitting(false);
    }, 500);

    toast.success(t("creatorReviews.toastSuccess"));
  };

  return (
    <div className="flex-1 p-6 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto">

        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">{t("creatorReviews.title")}</h1>
          <p className="text-gray-500 mt-1">{t("creatorReviews.subtitle")}</p>
        </div>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "received" | "write")} className="w-full">

          {/* Tabs */}
          <TabsList className="flex w-full mb-6 bg-transparent p-0 gap-0 border-0 rounded-none h-auto">
            <TabsTrigger
              value="received"
              className="flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium border-0
                text-gray-500 bg-transparent rounded-lg
                data-[state=active]:bg-purple-600 data-[state=active]:text-white data-[state=active]:shadow-none
                transition-all duration-200"
            >
              <MessageSquare className="w-4 h-4" />
              {t("creatorReviews.tabs.received")}
            </TabsTrigger>
            <TabsTrigger
              value="write"
              className="flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium border-0
                text-gray-500 bg-transparent rounded-lg
                data-[state=active]:bg-transparent data-[state=active]:text-gray-700 data-[state=active]:shadow-none
                transition-all duration-200"
            >
              <Sparkles className="w-4 h-4" />
              {t("creatorReviews.tabs.write")}
            </TabsTrigger>
          </TabsList>

          {/* Tab: Reseñas Recibidas */}
          <TabsContent value="received" className="space-y-4">

            {/* Rating card - ancho completo, centrado */}
            <div className="bg-gradient-to-r from-purple-600 to-purple-500 rounded-2xl p-10 flex flex-col items-center justify-center text-white">
              <div className="flex items-center gap-4 mb-2">
                <div className="bg-white/20 rounded-full p-3">
                  <Star className="w-8 h-8 text-yellow-300 fill-yellow-300" />
                </div>
                <span className="text-6xl font-bold">
                  {averageRating > 0 ? averageRating.toFixed(1) : t("creatorReviews.received.noRating")}
                </span>
              </div>
              <p className="text-purple-100 text-base mt-1">
                {t("creatorReviews.received.reviewCount", { count: reviews.length })}
              </p>
            </div>

            {/* Comentarios */}
            <div className="bg-white rounded-2xl shadow-sm p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-5 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-purple-500" />
                {t("creatorReviews.received.commentsTitle")}
              </h2>

              {reviews.length === 0 ? (
                <div className="text-center py-12">
                  <div className="bg-purple-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Star className="w-8 h-8 text-purple-400" />
                  </div>
                  <p className="font-semibold text-gray-700">{t("creatorReviews.received.empty.title")}</p>
                  <p className="text-sm text-gray-400 mt-1">{t("creatorReviews.received.empty.subtitle")}</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {reviews.map((review) => (
                    <div
                      key={review.id}
                      className="p-5 bg-purple-50/60 rounded-xl border border-purple-100"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="font-semibold text-gray-900">{review.from}</p>
                          <p className="text-sm text-gray-400 mt-0.5">{review.date}</p>
                        </div>
                        <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-lg shadow-sm">
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`w-4 h-4 ${star <= review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-200"}`}
                              />
                            ))}
                          </div>
                          <span className="text-sm font-bold text-gray-800">{review.rating}</span>
                        </div>
                      </div>
                      <p className="text-gray-600 text-sm leading-relaxed">{review.comment}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          {/* Tab: Escribir Reseña */}
          <TabsContent value="write" className="space-y-4">
            {collaboratedCompanies.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-sm p-12 text-center">
                <div className="bg-purple-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Building2 className="w-8 h-8 text-purple-400" />
                </div>
                <p className="font-semibold text-gray-700">{t("creatorReviews.write.noCollabs.title")}</p>
                <p className="text-sm text-gray-400 mt-1">{t("creatorReviews.write.noCollabs.subtitle")}</p>
              </div>
            ) : (
              <>
                {/* Banner */}
                <div className="bg-gradient-to-r from-purple-600 to-purple-500 rounded-xl p-4 flex items-center gap-3">
                  <div className="bg-white/20 p-2 rounded-lg">
                    <Sparkles className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-white">
                    <p className="text-sm font-semibold">{t("creatorReviews.write.banner.title")}</p>
                    <p className="text-xs text-purple-100">{t("creatorReviews.write.banner.subtitle")}</p>
                  </div>
                </div>

                {/* Cards empresas */}
                <div className="space-y-3">
                  {collaboratedCompanies.map((company) => (
                    <div
                      key={company.id}
                      className={`bg-white rounded-xl shadow-sm p-5 border transition-all duration-200 ${
                        selectedCompanyId === company.id
                          ? "border-purple-300 ring-1 ring-purple-200"
                          : "border-gray-100 hover:shadow-md"
                      }`}
                    >
                      <div className="flex items-center gap-3 mb-3">
                        <img
                          src={company.logo}
                          alt={company.name}
                          className="w-12 h-12 rounded-lg object-cover ring-1 ring-gray-200"
                        />
                        <div className="flex-1">
                          <p className="font-semibold text-gray-900">{company.name}</p>
                          <p className="text-xs text-gray-500">{company.sector}</p>
                        </div>
                        <div className="flex items-center gap-1 text-green-600">
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span className="text-xs font-medium">{t("creatorReviews.write.collabCompleted")}</span>
                        </div>
                      </div>

                      {selectedCompanyId === company.id ? (
                        <div className="space-y-4 pt-4 border-t border-gray-100">
                          <div>
                            <p className="text-xs font-semibold text-gray-700 mb-2">
                              {t("creatorReviews.write.form.ratingLabel")}
                            </p>
                            <div className="flex gap-1.5">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <button
                                  key={star}
                                  type="button"
                                  onClick={() => setRating(star)}
                                  onMouseEnter={() => setHoverRating(star)}
                                  onMouseLeave={() => setHoverRating(0)}
                                  className="transition-transform hover:scale-110"
                                >
                                  <Star
                                    className={`w-7 h-7 transition-colors ${
                                      star <= (hoverRating || rating)
                                        ? "text-yellow-400 fill-yellow-400"
                                        : "text-gray-200"
                                    }`}
                                  />
                                </button>
                              ))}
                            </div>
                          </div>
                          <div>
                            <p className="text-xs font-semibold text-gray-700 mb-2">
                              {t("creatorReviews.write.form.commentLabel")}
                            </p>
                            <Textarea
                              value={comment}
                              onChange={(e) => setComment(e.target.value)}
                              placeholder={t("creatorReviews.write.form.commentPlaceholder")}
                              className="min-h-[90px] resize-none text-sm border-gray-200 focus:border-purple-400 rounded-lg"
                            />
                          </div>
                          <div className="flex gap-2">
                            <Button
                              onClick={handleSubmitReview}
                              disabled={rating === 0 || !comment.trim() || submitting}
                              className="flex-1 bg-purple-600 hover:bg-purple-700 text-white text-sm h-9 rounded-lg border-0 disabled:opacity-50"
                            >
                              {submitting ? (
                                <>
                                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                                  {t("creatorReviews.write.form.submitting")}
                                </>
                              ) : (
                                <>
                                  <CheckCircle className="w-3.5 h-3.5 mr-1.5" />
                                  {t("creatorReviews.write.form.submitBtn")}
                                </>
                              )}
                            </Button>
                            <Button
                              variant="ghost"
                              onClick={() => { setSelectedCompanyId(null); setRating(0); setComment(""); }}
                              className="text-gray-500 hover:text-gray-700 hover:bg-gray-100 text-sm h-9 rounded-lg border-0"
                            >
                              {t("common.cancel")}
                            </Button>
                          </div>
                        </div>
                      ) : hasReviewedCompany(company.id) ? (
                        <div className="flex items-center gap-2 text-green-600 bg-green-50 px-3 py-2 rounded-lg">
                          <CheckCircle className="w-4 h-4" />
                          <span className="text-xs font-medium">{t("creatorReviews.write.alreadyReviewed")}</span>
                        </div>
                      ) : (
                        <Button
                          onClick={() => setSelectedCompanyId(company.id)}
                          className="w-full bg-purple-600 hover:bg-purple-700 text-white text-sm h-9 rounded-lg border-0"
                        >
                          <Star className="w-3.5 h-3.5 mr-1.5" />
                          {t("creatorReviews.write.writeBtn")}
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}