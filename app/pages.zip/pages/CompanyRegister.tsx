"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useUser, Company } from "@/app/context/UserContext";
import { useTranslation } from "react-i18next";
import {
  ArrowLeft, Upload, CheckCircle, XCircle, Eye, EyeOff,
  Loader2, Building2, Mail, Lock, AlertCircle, FileText,
  Edit, Briefcase, DollarSign, Target, HelpCircle, X,
} from "lucide-react";
import LanguageSwitcher from "@/app/components/LanguageSwitcher";

export default function CompanyRegister() {
  const { t } = useTranslation();
  const router = useRouter();
  const { userType, currentUser, setUserType, setCurrentUser, addCompany, updateCompany } = useUser();

  const isEditMode = userType === "company" && currentUser;
  const existingCompany = isEditMode ? (currentUser as Company) : null;

  const [isLoading, setIsLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [formData, setFormData] = useState({
    name: "", email: "", password: "", confirmPassword: "",
    sector: "", budget: "", companyDescription: "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [logoPreview, setLogoPreview] = useState<string>("");

  useEffect(() => {
    if (existingCompany) {
      setFormData({
        name: existingCompany.name || "",
        email: existingCompany.email || "",
        password: "", confirmPassword: "",
        sector: existingCompany.sector || "",
        budget: existingCompany.budget || "",
        companyDescription: existingCompany.objectives[0] || existingCompany.description || "",
      });
      setLogoPreview(existingCompany.logo || "");
    }
  }, [existingCompany]);

  const validateField = (name: string, value: string) => {
    let error = "";
    switch (name) {
      case "name":
        if (!value.trim()) error = t("companyRegister.validation.nameRequired");
        else if (value.trim().length < 3) error = t("companyRegister.validation.nameMin");
        break;
      case "email":
        if (!value.trim()) error = t("companyRegister.validation.emailRequired");
        else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) error = t("errors.invalidEmail");
        break;
      case "password":
        if (!isEditMode) {
          if (!value) error = t("companyRegister.validation.passwordRequired");
          else if (value.length < 6) error = t("companyRegister.validation.passwordMin");
        } else if (value && value.length < 6) error = t("companyRegister.validation.passwordMin");
        break;
      case "confirmPassword":
        if (!isEditMode) {
          if (!value) error = t("companyRegister.validation.confirmPasswordRequired");
          else if (value !== formData.password) error = t("errors.passwordMismatch");
        } else if (formData.password && value !== formData.password) error = t("errors.passwordMismatch");
        break;
      case "sector":
        if (!value) error = t("companyRegister.validation.sectorRequired");
        break;
      case "budget":
        if (!value) error = t("companyRegister.validation.budgetRequired");
        break;
      case "companyDescription":
        if (!value.trim()) error = t("companyRegister.validation.descriptionRequired");
        else if (value.trim().length < 20) error = t("companyRegister.validation.descriptionMin");
        break;
    }
    return error;
  };

  const handleFieldChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (touched[name]) setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleBlur = (name: string) => {
    setTouched((prev) => ({ ...prev, [name]: true }));
    setErrors((prev) => ({ ...prev, [name]: validateField(name, formData[name as keyof typeof formData]) }));
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setLogoPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    Object.keys(formData).forEach((key) => {
      const error = validateField(key, formData[key as keyof typeof formData]);
      if (error) newErrors[key] = error;
    });
    setErrors(newErrors);
    setTouched({ name: true, email: true, password: true, confirmPassword: true, sector: true, budget: true, companyDescription: true });
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;
    setShowConfirmModal(true);
  };

  const handleConfirmSubmit = async () => {
    setShowConfirmModal(false);
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 2000));

    if (isEditMode && existingCompany) {
      const updatedCompany: Partial<Company> = {
        name: formData.name, email: formData.email,
        logo: logoPreview || existingCompany.logo,
        sector: formData.sector, description: formData.companyDescription,
        budget: formData.budget, objectives: [formData.companyDescription],
      };
      updateCompany(existingCompany.id, updatedCompany);
      setCurrentUser({ ...existingCompany, ...updatedCompany });
    } else {
      const newCompany: Company = {
        id: `company-${Date.now()}`, name: formData.name, email: formData.email,
        logo: logoPreview || "https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=200",
        sector: formData.sector, description: formData.companyDescription,
        budget: formData.budget, objectives: [formData.companyDescription],
        rating: 0, reviews: [],
      };
      addCompany(newCompany);
      setUserType("company");
      setCurrentUser(newCompany);
    }
    setIsLoading(false);
    setShowSuccess(true);
    setTimeout(() => router.push("/company/profile"), 2000);
  };

  const getFieldStatus = (name: string) => {
    if (!touched[name]) return "default";
    if (errors[name]) return "error";
    if (formData[name as keyof typeof formData]) return "success";
    return "default";
  };

  const inputClass = (name: string) =>
    `w-full pl-11 pr-4 py-3 border rounded-lg outline-none transition-all ${
      getFieldStatus(name) === "error" ? "border-red-500 focus:ring-2 focus:ring-red-200" :
      getFieldStatus(name) === "success" ? "border-green-500 focus:ring-2 focus:ring-green-200" :
      "border-[#E5E7EB] focus:ring-2 focus:ring-[#0EA5E9]/20 focus:border-[#0EA5E9]"
    }`;

  return (
    <div className="min-h-screen bg-[#F3F4F6]">
      <header className="px-6 py-4 bg-white/80 backdrop-blur-sm shadow-sm sticky top-0 z-10 border-b border-[#E5E7EB]">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <button onClick={() => router.push(isEditMode ? "/company/profile" : "/")} className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors">
            <ArrowLeft className="w-5 h-5" />
            {isEditMode ? t("companyRegister.header.backToProfile") : t("common.back")}
          </button>
          <div className="flex items-center gap-4">
            <LanguageSwitcher />
            <span className="text-lg font-bold text-[#0EA5E9]">MatchCreator</span>
          </div>
          <div className="w-32">
            {!isEditMode && (
              <button onClick={() => router.push("/login")} className="px-6 py-2 text-gray-700 hover:text-[#0EA5E9] font-medium transition-colors">
                {t("companyRegister.header.alreadyHaveAccount")}
              </button>
            )}
          </div>
        </div>
      </header>

      <div className="px-6 py-8 max-w-6xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-[#1F2937] mb-2">
            {isEditMode ? t("companyRegister.title.edit") : t("companyRegister.title.create")}
          </h1>
          <p className="text-gray-600">
            {isEditMode ? t("companyRegister.subtitle.edit") : t("companyRegister.subtitle.create")}
          </p>
        </div>

        <div className="mb-8 bg-[#F9FAFB] rounded-lg p-6 border border-[#E5E7EB]">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <AlertCircle className="w-6 h-6 text-[#0EA5E9]" />
            </div>
            <div>
              <h3 className="font-semibold text-[#1F2937] mb-2">
                {isEditMode ? t("companyRegister.infoBlock.edit.title") : t("companyRegister.infoBlock.create.title")}
              </h3>
              <ul className="space-y-2 text-sm text-gray-600">
                {["check1", "check2", "check3"].map((check) => (
                  <li key={check} className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>{isEditMode ? t(`companyRegister.infoBlock.edit.${check}`) : t(`companyRegister.infoBlock.create.${check}`)}</span>
                  </li>
                ))}
                {!isEditMode && (
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>{t("companyRegister.infoBlock.create.check4")}</span>
                  </li>
                )}
              </ul>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* FORM */}
          <div className="md:col-span-2">
            {!showSuccess ? (
              <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-sm p-8 border border-[#E5E7EB]">
                <h2 className="text-xl font-bold text-[#1F2937] mb-6 flex items-center gap-2">
                  {isEditMode ? <Edit className="w-6 h-6 text-[#0EA5E9]" /> : <FileText className="w-6 h-6 text-[#0EA5E9]" />}
                  {isEditMode ? t("companyRegister.form.titleEdit") : t("companyRegister.form.titleCreate")}
                </h2>

                {/* Name */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-[#1F2937] mb-2">{t("companyRegister.fields.name")} *</label>
                  <div className="relative">
                    <Building2 className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${getFieldStatus("name") === "error" ? "text-red-500" : getFieldStatus("name") === "success" ? "text-green-500" : "text-gray-400"}`} />
                    <input type="text" value={formData.name} onChange={(e) => handleFieldChange("name", e.target.value)} onBlur={() => handleBlur("name")} placeholder={t("companyRegister.placeholders.name")} className={inputClass("name")} />
                    {getFieldStatus("name") === "success" && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-green-500" />}
                  </div>
                  {touched.name && errors.name && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><XCircle className="w-3 h-3" />{errors.name}</p>}
                </div>

                {/* Logo */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-[#1F2937] mb-2">
                    {t("companyRegister.fields.logo")} <span className="ml-2 text-xs font-normal text-gray-500">({t("companyRegister.fields.logoOptional")})</span>
                  </label>
                  <div className="border-2 border-dashed border-[#E5E7EB] rounded-lg p-6 text-center hover:border-[#0EA5E9] transition-colors">
                    {logoPreview ? (
                      <div className="space-y-3">
                        <img src={logoPreview} alt="Logo" className="w-24 h-24 object-cover mx-auto rounded-lg" />
                        <button type="button" onClick={() => setLogoPreview("")} className="text-sm text-red-500 hover:text-red-700">{t("companyRegister.logo.remove")}</button>
                      </div>
                    ) : (
                      <>
                        <Upload className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-600 mb-2">{t("companyRegister.logo.uploadPrompt")}</p>
                        <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" id="logo-upload" />
                        <label htmlFor="logo-upload" className="inline-block px-4 py-2 bg-[#0EA5E9] text-white rounded-lg text-sm font-medium hover:bg-[#0EA5E9]/90 cursor-pointer">{t("companyRegister.logo.selectFile")}</label>
                      </>
                    )}
                  </div>
                </div>

                {/* Email */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-[#1F2937] mb-2">{t("companyRegister.fields.email")} *</label>
                  <div className="relative">
                    <Mail className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${getFieldStatus("email") === "error" ? "text-red-500" : getFieldStatus("email") === "success" ? "text-green-500" : "text-gray-400"}`} />
                    <input type="email" value={formData.email} onChange={(e) => handleFieldChange("email", e.target.value)} onBlur={() => handleBlur("email")} placeholder={t("companyRegister.placeholders.email")} className={inputClass("email")} />
                    {getFieldStatus("email") === "success" && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-green-500" />}
                  </div>
                  {touched.email && errors.email && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><XCircle className="w-3 h-3" />{errors.email}</p>}
                </div>

                {/* Password */}
                {!isEditMode && (
                  <>
                    <div className="mb-6">
                      <label className="block text-sm font-semibold text-[#1F2937] mb-2">{t("companyRegister.fields.password")} *</label>
                      <div className="relative">
                        <Lock className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${getFieldStatus("password") === "error" ? "text-red-500" : getFieldStatus("password") === "success" ? "text-green-500" : "text-gray-400"}`} />
                        <input type={showPassword ? "text" : "password"} value={formData.password} onChange={(e) => handleFieldChange("password", e.target.value)} onBlur={() => handleBlur("password")} placeholder={t("companyRegister.placeholders.password")} className={`${inputClass("password")} pr-11`} />
                        <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                          {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                      {touched.password && errors.password && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><XCircle className="w-3 h-3" />{errors.password}</p>}
                    </div>
                    <div className="mb-6">
                      <label className="block text-sm font-semibold text-[#1F2937] mb-2">{t("companyRegister.fields.confirmPassword")} *</label>
                      <div className="relative">
                        <Lock className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${getFieldStatus("confirmPassword") === "error" ? "text-red-500" : getFieldStatus("confirmPassword") === "success" ? "text-green-500" : "text-gray-400"}`} />
                        <input type={showConfirmPassword ? "text" : "password"} value={formData.confirmPassword} onChange={(e) => handleFieldChange("confirmPassword", e.target.value)} onBlur={() => handleBlur("confirmPassword")} placeholder={t("companyRegister.placeholders.confirmPassword")} className={`${inputClass("confirmPassword")} pr-11`} />
                        <button type="button" onClick={() => setShowConfirmPassword(!showConfirmPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                          {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                      {touched.confirmPassword && errors.confirmPassword && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><XCircle className="w-3 h-3" />{errors.confirmPassword}</p>}
                    </div>
                  </>
                )}

                {/* Sector */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-[#1F2937] mb-2">{t("companyRegister.fields.sector")} *</label>
                  <div className="relative">
                    <Briefcase className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${getFieldStatus("sector") === "error" ? "text-red-500" : getFieldStatus("sector") === "success" ? "text-green-500" : "text-gray-400"}`} />
                    <select value={formData.sector} onChange={(e) => handleFieldChange("sector", e.target.value)} onBlur={() => handleBlur("sector")} className={inputClass("sector")}>
                      <option value="">{t("companyRegister.placeholders.sector")}</option>
                      {["technology","fashion","foodBeverage","healthWellness","education","entertainment","beauty","sports","travel","finance","other"].map((key) => (
                        <option key={key} value={t(`companyRegister.sectors.${key}`)}>{t(`companyRegister.sectors.${key}`)}</option>
                      ))}
                    </select>
                  </div>
                  {touched.sector && errors.sector && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><XCircle className="w-3 h-3" />{errors.sector}</p>}
                </div>

                {/* Budget */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-[#1F2937] mb-2">{t("companyRegister.fields.budget")} *</label>
                  <div className="relative">
                    <DollarSign className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${getFieldStatus("budget") === "error" ? "text-red-500" : getFieldStatus("budget") === "success" ? "text-green-500" : "text-gray-400"}`} />
                    <select value={formData.budget} onChange={(e) => handleFieldChange("budget", e.target.value)} onBlur={() => handleBlur("budget")} className={inputClass("budget")}>
                      <option value="">{t("companyRegister.placeholders.budget")}</option>
                      {["$500 - $1,000","$1,000 - $3,000","$3,000 - $5,000","$5,000 - $10,000","$10,000+"].map((v) => (
                        <option key={v} value={v}>{v}</option>
                      ))}
                    </select>
                  </div>
                  {touched.budget && errors.budget && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><XCircle className="w-3 h-3" />{errors.budget}</p>}
                </div>

                {/* Description */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-[#1F2937] mb-2">{t("companyRegister.fields.description")} *</label>
                  <textarea value={formData.companyDescription} onChange={(e) => handleFieldChange("companyDescription", e.target.value)} onBlur={() => handleBlur("companyDescription")} placeholder={t("companyRegister.placeholders.description")} rows={4} className={`w-full px-4 py-3 border rounded-lg outline-none transition-all resize-none ${getFieldStatus("companyDescription") === "error" ? "border-red-500 focus:ring-2 focus:ring-red-200" : getFieldStatus("companyDescription") === "success" ? "border-green-500 focus:ring-2 focus:ring-green-200" : "border-[#E5E7EB] focus:ring-2 focus:ring-[#0EA5E9]/20 focus:border-[#0EA5E9]"}`} />
                  {touched.companyDescription && errors.companyDescription && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><XCircle className="w-3 h-3" />{errors.companyDescription}</p>}
                </div>

                {/* Actions */}
                <div className="space-y-3">
                  <button type="submit" disabled={isLoading} className="w-full py-4 bg-gradient-to-r from-[#0EA5E9] to-[#38BDF8] text-white rounded-lg font-semibold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2">
                    {isLoading ? <><Loader2 className="w-5 h-5 animate-spin" />{isEditMode ? t("companyRegister.submit.saving") : t("companyRegister.submit.creating")}</> : <><CheckCircle className="w-5 h-5" />{isEditMode ? t("companyRegister.submit.saveChanges") : t("companyRegister.submit.create")}</>}
                  </button>
                  <button type="button" onClick={() => { setFormData({ name: "", email: "", password: "", confirmPassword: "", sector: "", budget: "", companyDescription: "" }); setErrors({}); setTouched({}); setLogoPreview(""); }} className="w-full py-3 border-2 border-[#E5E7EB] text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-all">
                    {isEditMode ? t("companyRegister.submit.undoChanges") : t("companyRegister.submit.clearForm")}
                  </button>
                </div>
              </form>
            ) : (
              <div className="bg-white rounded-lg shadow-sm p-8 border border-[#E5E7EB] text-center">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-10 h-10 text-green-600" />
                </div>
                <h2 className="text-2xl font-bold text-[#1F2937] mb-2">
                  {isEditMode ? t("companyRegister.success.titleEdit") : t("companyRegister.success.titleCreate")}
                </h2>
                <p className="text-gray-600 mb-6">
                  {isEditMode ? t("companyRegister.success.subtitleEdit") : t("companyRegister.success.subtitleCreate")}
                </p>
                <p className="text-sm text-gray-600">{t("companyRegister.success.redirecting")}</p>
              </div>
            )}
          </div>

          {/* SIDEBAR */}
          <div className="space-y-6">
            {formData.name && formData.sector && (
              <div className="bg-white rounded-lg shadow-sm p-6 border border-[#E5E7EB]">
                <h3 className="font-semibold text-[#1F2937] mb-2">{t("companyRegister.preview.title")}</h3>
                <p className="text-xs text-gray-500 mb-4">{t("companyRegister.preview.subtitle")}</p>
                <div className="flex justify-center mb-4">
                  <div className="w-20 h-20 bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8] rounded-lg flex items-center justify-center">
                    {logoPreview ? <img src={logoPreview} alt="Logo" className="w-full h-full object-cover rounded-lg" /> : <Building2 className="w-10 h-10 text-white" />}
                  </div>
                </div>
                <div className="text-center border-t border-[#E5E7EB] pt-4">
                  <h4 className="font-bold text-[#1F2937] text-lg mb-1">{formData.name}</h4>
                  <p className="text-sm text-gray-600 mb-3">{formData.sector}</p>
                  {formData.budget && (
                    <div className="flex items-start gap-2 text-left">
                      <DollarSign className="w-4 h-4 text-[#0EA5E9] mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="text-xs text-gray-500">{t("companyRegister.preview.budgetLabel")}</p>
                        <p className="text-sm font-medium text-[#1F2937]">{formData.budget}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
              <div className="flex items-start gap-3">
                <HelpCircle className="w-6 h-6 text-[#0EA5E9] flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-[#1F2937] mb-2">{t("companyRegister.help.title")}</h3>
                  <p className="text-sm text-gray-600">{t("companyRegister.help.subtitle")}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6 border border-[#E5E7EB]">
              <h3 className="font-semibold text-[#1F2937] mb-3">{t("companyRegister.tips.title")}</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                {["tip1","tip2","tip3"].map((tip) => (
                  <li key={tip} className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>{t(`companyRegister.tips.${tip}`)}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* MODAL */}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-2xl max-w-md w-full p-6">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <AlertCircle className="w-6 h-6 text-[#0EA5E9]" />
              </div>
              <div>
                <h3 className="font-bold text-[#1F2937] text-lg mb-2">
                  {isEditMode ? t("companyRegister.modal.titleEdit") : t("companyRegister.modal.titleCreate")}
                </h3>
                <p className="text-sm text-gray-600">
                  {isEditMode ? t("companyRegister.modal.subtitleEdit") : t("companyRegister.modal.subtitleCreate")}
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setShowConfirmModal(false)} className="flex-1 py-3 border-2 border-[#E5E7EB] text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-all">{t("common.cancel")}</button>
              <button onClick={handleConfirmSubmit} className="flex-1 py-3 bg-gradient-to-r from-[#0EA5E9] to-[#38BDF8] text-white rounded-lg font-semibold hover:shadow-lg transition-all">{t("common.confirm")}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}